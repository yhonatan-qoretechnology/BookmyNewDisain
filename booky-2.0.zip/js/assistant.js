/* ==========================================================================
   Bookmy · assistant.js — Asistente vendedor
   - Funciona sin servidor (modo guiado): entiende preguntas frecuentes,
     recomienda plan (Plan Basic o Plan Pro, los dos con 7 días gratis),
     calcula lo que se pierde por ausencias en la moneda del país del
     negocio, rebate objeciones y capta contactos con consentimiento RGPD.
   - En las páginas de la App atiende también a quien quiere reservar.
   - Con un endpoint (api/asistente.php) responde con un modelo de IA real
     y mantiene los flujos guiados.
   Configuración: edita CONFIG o define window.BOOKMY_ASSISTANT antes de
   cargar este archivo.
   Botones que abren el chat: data-assistant-open · data-assistant-flow="roi|recomendar"
   · data-assistant-ask="texto"
   ========================================================================== */
(() => {
  'use strict';

  const CONFIG = Object.assign({
    name: 'Asistente Bookmy',
    endpoint: '',            // 'api/asistente.php' → respuestas con IA (ver README)
    leadEndpoint: '',        // 'api/lead.php' → te llegan los contactos por email
    basicPrice: '',          // p. ej. '9 €/mes + IVA'. Vacío: no se menciona precio
    proPrice: '',            // p. ej. '29 €/mes + IVA'. Vacío: no se menciona precio
    trialDays: 7,            // días de prueba gratis de los dos planes
    whatsapp: '34651026700',
    email: 'contacto@bookmy.es',
    signupBasic: 'crear-cuenta.html?plan=basic',
    signupPro: 'crear-cuenta.html?plan=pro',
    login: 'https://bookmy.es/login',
    playStore: 'https://play.google.com/store/search?q=bookmy',
    appStore: 'https://apps.apple.com/search?term=bookmy',
    apk: 'descargas/bookmy.apk',
    teaserDelay: 9000,
  }, window.BOOKMY_ASSISTANT || {});

  const AI = Boolean(CONFIG.endpoint);
  const page = document.body.dataset.page || '';
  const CONSUMER = page === 'app';            // app para personas: puede escribir alguien que quiere reservar
  const DAYS = CONFIG.trialDays;
  const MONEY = window.BookmyMoney;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Utilidades ------------------------------------------------------------ */
  const $ = (s, c = document) => c.querySelector(s);
  const sleep = (ms) => new Promise((r) => setTimeout(r, reduce ? Math.min(ms, 180) : ms));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (v, code) => (MONEY ? MONEY.format(v, code) : new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(v));
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
  const NUMS = { un: 1, uno: 1, una: 1, dos: 2, tres: 3, cuatro: 4, cinco: 5, seis: 6, siete: 7, ocho: 8, nueve: 9, diez: 10, quince: 15, veinte: 20, treinta: 30, cuarenta: 40, cincuenta: 50, cien: 100 };
  const norm = (s) => ` ${String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9€%\s]/g, ' ').replace(/\s+/g, ' ').trim()
    .split(' ').map((w) => (NUMS[w] !== undefined ? String(NUMS[w]) : w)).join(' ')} `;
  const has = (n, kw) => n.includes(` ${kw} `);
  const firstNum = (n) => { const m = n.match(/(\d+(?:[.,]\d+)?)/); return m ? parseFloat(m[1].replace(',', '.')) : null; };
  const LINK_RE = /\[([^\]]+)\]\(((?:https?:\/\/|mailto:|tel:)[^\s)]+|[\w-]+\.html(?:\?[\w=&-]+)?(?:#[\w-]+)?|descargas\/[\w.-]+)\)/g;
  const inline = (s) => s.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(LINK_RE, (m, t, u) => `<a href="${u}"${/^https?:/.test(u) ? ' target="_blank" rel="noopener"' : ''}>${t}</a>`);
  function md(src) {
    let html = '';
    let list = false;
    let para = [];
    const flush = () => { if (para.length) { html += `<p>${inline(para.join('<br>'))}</p>`; para = []; } };
    esc(src).split('\n').forEach((raw) => {
      const l = raw.trim();
      if (/^[-•]\s+/.test(l)) {
        flush();
        if (!list) { html += '<ul>'; list = true; }
        html += `<li>${inline(l.replace(/^[-•]\s+/, ''))}</li>`;
        return;
      }
      if (list) { html += '</ul>'; list = false; }
      if (!l) flush(); else para.push(l);
    });
    flush();
    if (list) html += '</ul>';
    return html;
  }
  const wa = (text) => `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;

  /* Estado (sesión; persiste entre visitas solo con cookies funcionales) -- */
  const KEY = 'bookmy_ai';
  const store = () => (window.BookmyConsent?.has('functional') ? localStorage : sessionStorage);
  const blank = () => ({ msgs: [], chips: [], profile: {}, flow: null, turns: 0, lead: false, nudged: false, opened: false });
  let S;
  try { S = JSON.parse(store().getItem(KEY)) || blank(); } catch { S = blank(); }
  const persist = () => {
    try { S.msgs = S.msgs.slice(-60); store().setItem(KEY, JSON.stringify(S)); } catch { /* sin almacenamiento */ }
  };
  document.addEventListener('bookmy:consent', (e) => {
    try {
      if (e.detail?.functional) localStorage.setItem(KEY, JSON.stringify(S));
      else localStorage.removeItem(KEY);
    } catch { /* nada */ }
  });

  /* Interfaz ------------------------------------------------------------- */
  const ui = document.createElement('div');
  ui.className = 'ai-root';
  ui.innerHTML = `
    <button class="ai-launcher" type="button" aria-label="Abrir el ${esc(CONFIG.name)}" aria-expanded="false" aria-controls="ai-panel">
      <i class="i i-sparkles" aria-hidden="true"></i><span class="ai-launcher__dot" hidden></span>
    </button>
    <div class="ai-teaser" role="status">
      <button class="ai-teaser__close" type="button" aria-label="Cerrar sugerencia"><i class="i i-x" aria-hidden="true"></i></button>
      <button class="ai-teaser__txt" type="button"></button>
      <small>${AI ? 'Asistente con IA · responde al instante' : 'Responde al instante'}</small>
    </div>
    <section class="ai-panel" id="ai-panel" role="dialog" aria-label="${esc(CONFIG.name)}" aria-hidden="true">
      <header class="ai-head">
        <span class="orb-av" aria-hidden="true"></span>
        <div class="ai-head__txt">
          <b>${esc(CONFIG.name)}${AI ? ' <span class="tag tag--dark">IA</span>' : ''}</b>
          <small>En línea · responde al instante</small>
        </div>
        <button class="ai-head__btn" type="button" data-ai="reset" aria-label="Empezar de nuevo"><i class="i i-rotate-ccw" aria-hidden="true"></i></button>
        <button class="ai-head__btn" type="button" data-ai="close" aria-label="Cerrar el asistente"><i class="i i-x" aria-hidden="true"></i></button>
      </header>
      <div class="ai-log" aria-live="polite"></div>
      <form class="ai-compose" autocomplete="off">
        <label class="sr-only" for="ai-input">Escribe tu mensaje</label>
        <textarea id="ai-input" rows="1" maxlength="600" placeholder="Pregúntame lo que quieras…"></textarea>
        <button class="ai-send" type="submit" aria-label="Enviar" disabled><i class="i i-send" aria-hidden="true"></i></button>
      </form>
      <p class="ai-foot">${AI ? 'Asistente con IA · puede equivocarse' : 'Asistente virtual de Bookmy'} · <a href="privacidad.html#asistente">Privacidad</a></p>
    </section>`;
  document.body.append(ui);

  const launcher = $('.ai-launcher', ui);
  const dot = $('.ai-launcher__dot', ui);
  const teaser = $('.ai-teaser', ui);
  const panel = $('.ai-panel', ui);
  const log = $('.ai-log', ui);
  const form = $('.ai-compose', ui);
  const input = $('#ai-input', ui);
  const send = $('.ai-send', ui);
  panel.inert = true;

  const scrollDown = (instant) => {
    if (instant) { log.style.scrollBehavior = 'auto'; log.scrollTop = log.scrollHeight; log.style.scrollBehavior = ''; }
    else log.scrollTop = log.scrollHeight;
  };

  function addDisclaimer() {
    const p = document.createElement('p');
    p.className = 'ai-disclaimer';
    p.innerHTML = AI
      ? 'Soy un asistente virtual con inteligencia artificial y puedo equivocarme. Para temas de tu cuenta o pagos, te paso con el equipo. <a href="privacidad.html#asistente">Cómo tratamos tus datos</a>.'
      : 'Soy el asistente virtual de Bookmy. Para temas de tu cuenta o pagos, te paso con el equipo. <a href="privacidad.html#asistente">Cómo tratamos tus datos</a>.';
    log.append(p);
  }

  function renderMsg(m) {
    if (m.from === 'card') {
      const c = document.createElement('div');
      c.className = `ai-card${m.dark ? ' ai-card--dark' : ''}`;
      c.innerHTML = m.html;
      log.append(c);
      return c;
    }
    const row = document.createElement('div');
    row.className = `ai-msg ai-msg--${m.from}`;
    row.innerHTML = `${m.from === 'bot' ? '<span class="orb-av" aria-hidden="true"></span>' : ''}<div class="ai-bubble">${m.from === 'bot' ? md(m.text) : esc(m.text).replace(/\n/g, '<br>')}</div>`;
    log.append(row);
    return row;
  }

  function addMsg(from, text) {
    const m = { from, text };
    S.msgs.push(m);
    persist();
    renderMsg(m);
    scrollDown();
  }

  function addCard(html, dark, keep = true) {
    const m = { from: 'card', html, dark };
    if (keep) { S.msgs.push(m); persist(); }
    const el = renderMsg(m);
    scrollDown();
    return el;
  }

  function showTyping() {
    const t = document.createElement('div');
    t.className = 'ai-typing typing';
    t.setAttribute('aria-hidden', 'true');
    t.innerHTML = '<i></i><i></i><i></i>';
    log.append(t);
    scrollDown();
    return t;
  }

  async function say(text) {
    const t = showTyping();
    await sleep(Math.min(1500, 380 + text.length * 7));
    t.remove();
    addMsg('bot', text);
  }

  function clearChips() {
    log.querySelectorAll('.ai-chips').forEach((c) => c.remove());
    S.chips = [];
    persist();
  }

  function renderChips(list) {
    log.querySelectorAll('.ai-chips').forEach((c) => c.remove());
    if (!list.length) return;
    const wrap = document.createElement('div');
    wrap.className = 'ai-chips';
    list.forEach((c, i) => {
      const el = document.createElement(c.href ? 'a' : 'button');
      el.className = `ai-chip${c.primary ? ' ai-chip--primary' : ''}`;
      el.textContent = c.label;
      el.dataset.idx = String(i);
      if (c.href) { el.href = c.href; el.target = '_blank'; el.rel = 'noopener'; } else el.type = 'button';
      wrap.append(el);
    });
    log.append(wrap);
    scrollDown();
  }

  function chips(list) {
    S.chips = list.map((c) => ({ ...c, href: typeof c.href === 'function' ? c.href() : c.href }));
    persist();
    renderChips(S.chips);
  }

  /* Conocimiento ---------------------------------------------------------- */
  const C = {
    que_es: { label: '¿Qué es Bookmy?', act: 'que_es' },
    recomendar: { label: 'Recomiéndame un plan', act: 'flow:recomendar' },
    roi: { label: '¿Cuánto pierdo por ausencias?', act: 'flow:roi' },
    planes: { label: 'Planes y precios', act: 'precio' },
    trial: { label: `Probar Plan Pro ${DAYS} días gratis`, href: () => CONFIG.signupPro, primary: true },
    basic: { label: `Probar Plan Basic ${DAYS} días gratis`, href: () => CONFIG.signupBasic },
    descargar: { label: 'Descargar la app', act: 'descargar' },
    reservar: { label: '¿Cómo reservo una cita?', act: 'reservar' },
    negocio: { label: 'Tengo un negocio', act: 'empresas_app' },
    demo: { label: 'Hablar con una persona', act: 'demo' },
    ia: { label: '¿Qué hace la IA?', act: 'ia' },
    funciona: { label: '¿Cómo empiezo?', act: 'funciona' },
  };
  const sectorChips = () => [
    ['Estética', 'estetica'], ['Peluquería o barbería', 'peluqueria'], ['Salud', 'salud'], ['Otro sector', 'servicios'],
  ].map(([label, s]) => ({ label, act: `sector:${s}` }));

  const SECTORS = [
    ['estetica', 'estética', ['estetica', 'belleza', 'unas', 'manicura', 'pedicura', 'pestanas', 'cejas', 'depilacion', 'maquillaje', 'spa', 'masajes', 'masaje', 'facial', 'micropigmentacion', 'nails', 'lash']],
    ['peluqueria', 'peluquería o barbería', ['peluqueria', 'peluquero', 'peluquera', 'barberia', 'barbero', 'salon', 'colorista']],
    ['salud', 'salud', ['salud', 'fisio', 'fisioterapia', 'fisioterapeuta', 'clinica', 'dental', 'dentista', 'psicologo', 'psicologa', 'psicologia', 'nutricionista', 'podologo', 'podologia', 'osteopata', 'medico', 'veterinaria', 'veterinario', 'logopeda']],
    ['bienestar', 'deporte y bienestar', ['gimnasio', 'yoga', 'pilates', 'entrenador', 'entrenadora', 'crossfit', 'danza']],
    ['tatuajes', 'tatuaje', ['tatuaje', 'tatuajes', 'tattoo', 'piercing']],
    ['construccion', 'construcción y reformas', ['construccion', 'reformas', 'reforma', 'obra', 'obras', 'fontanero', 'electricista', 'instalador', 'arquitecto', 'carpinteria']],
    ['tecnologia', 'tecnología', ['tecnologia', 'software', 'informatica', 'reparacion', 'reparaciones']],
    ['servicios', 'servicios', ['academia', 'clases', 'abogado', 'asesoria', 'gestoria', 'consultoria', 'fotografo', 'fotografia', 'taller', 'autoescuela', 'servicios', 'otro']],
  ];

  const PITCH = {
    estetica: 'En **estética** cada hueco vacío y cada clienta que no repite cuesta dinero. Con Bookmy tus clientas reservan 24/7, reciben recordatorio, y tú tienes la ficha de cada una con sus tratamientos y preferencias. Además controlas productos e insumos, y la IA puede sugerir el siguiente servicio en el momento justo.',
    peluqueria: 'En **peluquería y barbería** el día va a mil. Bookmy te quita el teléfono de encima: tus clientes eligen profesional y hora solos, reciben recordatorio, y tú ves la agenda de todo el equipo en tiempo real con el historial de cada cliente.',
    salud: 'En **salud** la agenda lo es todo. Bookmy organiza las citas por profesional, envía confirmaciones y recordatorios automáticos y guarda el historial de visitas de cada paciente, con acceso controlado por usuario.',
    bienestar: 'En **deporte y bienestar** Bookmy organiza citas y sesiones por profesional y horario, y te ayuda a que tus clientes repitan con recordatorios y mensajes automáticos.',
    tatuajes: 'En **tatuaje y piercing** Bookmy organiza la agenda de cada artista, guarda el historial de cada cliente y te deja cobrar online o en el estudio con trazabilidad.',
    construccion: 'En **construcción y reformas** Bookmy te sirve para agendar visitas técnicas y citas con clientes, coordinar a tu equipo y tener el historial de cada cliente en un solo panel.',
    tecnologia: 'En **tecnología** Bookmy agenda demos, visitas técnicas y citas de soporte, las asigna al profesional adecuado y te da estadísticas para ver dónde se va el tiempo.',
    servicios: 'Para **servicios profesionales** Bookmy centraliza citas, clientes, cobros y equipo, para que tu agenda se llene sola y tú te dediques a trabajar.',
  };

  const INTENTS = [
    ['apk', ['apk', 'sin google play', 'sin play store', 'no tengo google play', 'no tengo play store', 'huawei', 'archivo apk', 'instalar apk', 'descargar apk', 'descargar el apk', 'hay apk']],
    ['empresas_app', ['aparecer en la app', 'aparezco en la app', 'como aparezco', 'salir en la app', 'estar en la app', 'aparecer en bookmy', 'publicar mi negocio', 'mi negocio en la app', 'registrar mi negocio', 'anunciar mi negocio', 'tengo un negocio', 'soy un negocio']],
    ['reservar', ['como reservo', 'quiero reservar', 'reservar una cita', 'pedir cita', 'pedir una cita', 'coger cita', 'sacar cita', 'hacer una reserva', 'reservar un servicio']],
    ['cancelar', ['cancelar mi cita', 'cancelar una cita', 'cancelar mi reserva', 'cambiar mi cita', 'cambiar la cita', 'mover mi cita', 'anular mi cita', 'anular la cita']],
    ['gratis_app', ['app es gratis', 'app gratis', 'cuesta la app', 'pagar la app', 'gratis la app', 'la app cuesta']],
    ['descargar', ['descargar', 'descargo', 'descarga', 'bajar la app', 'me la bajo', 'instalar la app', 'donde la descargo', 'play store', 'google play', 'app store']],
    ['soporte', ['soporte', 'no puedo entrar', 'no me deja', 'contrasena', 'olvide', 'mi cuenta', 'error', 'no funciona', 'incidencia', 'ya soy cliente', 'mi panel']],
    ['demo', ['demo', 'demostracion', 'reunion', 'llamada', 'llamadme', 'llamame', 'que me llamen', 'videollamada', 'hablar con ventas', 'hablar con alguien', 'hablar con una persona', 'persona', 'humano', 'asesor', 'comercial', 'agente', 'contactar', 'contacto']],
    ['roi', ['cuanto pierdo', 'pierdo dinero', 'rentable', 'rentabilidad', 'retorno', 'roi', 'merece la pena', 'vale la pena', 'compensa', 'calcular', 'calculo']],
    ['recomendar', ['que plan', 'cual plan', 'me recomiendas', 'recomiendame', 'recomendacion', 'cual me conviene', 'cual elijo', 'cual elegir', 'que me conviene']],
    ['caro', ['caro', 'muy caro', 'presupuesto', 'barato', 'descuento', 'oferta', 'no me lo puedo permitir']],
    ['precio', ['precio', 'precios', 'cuesta', 'cuanto vale', 'coste', 'costo', 'tarifa', 'tarifas', 'mensualidad', 'cuota', 'cuanto es', 'cuanto cuesta']],
    ['prueba', ['prueba', 'probar', 'trial', '7 dias', 'dias gratis', 'sin tarjeta', 'periodo de prueba', 'prueba gratis']],
    ['planes', ['plan', 'planes', 'basic', 'basico', 'plan basic', 'plan pro', 'free', 'gratis', 'gratuito', 'pro', 'crm pro', 'version', 'diferencia', 'comparar', 'comparativa']],
    ['permanencia', ['permanencia', 'darme de baja', 'dar de baja', 'baja', 'cancelar la suscripcion', 'cancelar suscripcion', 'contrato', 'compromiso']],
    ['ya_uso', ['ya uso', 'ya tengo', 'uso otra', 'otra app', 'otro programa', 'otra herramienta', 'vengo de', 'cambiarme', 'migrar', 'migracion', 'importar', 'excel', 'papel', 'libreta', 'cuaderno']],
    ['tiempo', ['no tengo tiempo', 'complicado', 'dificil', 'no se de tecnologia', 'no soy de tecnologia', 'lio', 'tecnologico', 'tecnologica']],
    ['whatsapp', ['whatsapp', 'me escriben', 'me reservan por', 'por telefono', 'me llaman', 'instagram', 'dm']],
    ['ia', ['ia', 'inteligencia artificial', 'asistente', 'chatbot', 'bot', 'gpt', 'vendedor', 'vende solo']],
    ['ausencias', ['no show', 'no shows', 'ausencias', 'faltan', 'no vienen', 'no se presentan', 'plantones', 'plantan', 'cancelaciones', 'cancelan', 'recordatorio', 'recordatorios']],
    ['pagos', ['pago', 'pagos', 'cobrar', 'cobro', 'cobros', 'factura', 'facturas', 'facturacion', 'tarjeta', 'datafono', 'senal', 'deposito', 'adelanto']],
    ['crm', ['crm', 'clientes', 'ficha', 'historial', 'base de datos', 'fidelizar', 'fidelizacion', 'repetir', 'recurrentes']],
    ['equipo', ['equipo', 'empleados', 'empleadas', 'trabajadores', 'personal', 'profesionales', 'roles', 'horarios']],
    ['sedes', ['sede', 'sedes', 'sucursal', 'sucursales', 'locales', 'franquicia', 'varios centros', 'cadena']],
    ['stock', ['stock', 'inventario', 'insumos', 'productos', 'almacen', 'material']],
    ['estadisticas', ['estadisticas', 'informes', 'reportes', 'metricas', 'dashboard', 'kpi', 'ingresos']],
    ['resenas', ['resenas', 'opiniones', 'valoraciones', 'reputacion', 'estrellas', 'reviews']],
    ['comunicacion', ['comunicacion', 'mensajes', 'sms', 'email', 'correo', 'campanas', 'campana', 'promociones', 'marketing', 'newsletter']],
    ['automatizar', ['automatizar', 'automatizacion', 'automatizaciones', 'automatico', 'automaticos', 'automaticamente']],
    ['app', ['app', 'aplicacion', 'movil', 'android', 'iphone', 'ios', 'tablet']],
    ['seguridad', ['seguridad', 'seguro', 'rgpd', 'gdpr', 'proteccion de datos', 'privacidad', 'lopd', 'datos personales', 'cifrado', 'mis datos']],
    ['idioma', ['ingles', 'idioma', 'idiomas', 'english']],
    ['quienes', ['quienes sois', 'quien esta detras', 'empresa', 'sobre bookmy', 'donde estais', 'de donde sois', 'ubicacion', 'direccion']],
    ['funciona', ['como funciona', 'como empiezo', 'como se usa', 'pasos', 'configurar', 'configuracion', 'empezar', 'registrarme', 'crear cuenta', 'darme de alta']],
    ['reservas', ['reserva', 'reservas', 'reservar', 'cita', 'citas', 'agenda', 'calendario', 'turnos', 'huecos', 'disponibilidad', 'perfil publico']],
    ['que_es', ['que es bookmy', 'que es', 'que haceis', 'que hace', 'para que sirve', 'funciones', 'funcionalidades', 'caracteristicas', 'que incluye', 'modulos', 'que ofrece']],
    ['gracias', ['gracias', 'genial', 'perfecto', 'vale', 'ok', 'estupendo', 'guay']],
    ['saludo', ['hola', 'buenas', 'buenos dias', 'buenas tardes', 'buenas noches', 'hey', 'que tal', 'saludos']],
    ['despedida', ['adios', 'hasta luego', 'chao', 'nos vemos', 'lo pienso', 'me lo pienso']],
  ];
  const SOFT = ['gracias', 'saludo', 'despedida'];
  // Las palabras clave pasan por la misma normalización que el texto («un» → «1»)
  INTENTS.forEach((it) => { it[1] = it[1].map((k) => norm(k).trim()); });

  function detect(n) {
    let best = null;
    let bestScore = 0;
    let bestHard = null;
    let bestHardScore = 0;
    INTENTS.forEach(([id, kws]) => {
      let score = 0;
      kws.forEach((kw) => { if (has(n, kw)) score += kw.split(' ').length * 2 + (kw.length > 6 ? 1 : 0); });
      if (score > bestScore) { best = id; bestScore = score; }
      if (!SOFT.includes(id) && score > bestHardScore) { bestHard = id; bestHardScore = score; }
    });
    if (bestHard) return bestHard;
    if (best) return best;
    return S.profile.sector && !S.profile.pitched ? 'sector' : 'fallback';
  }

  function extract(raw, n) {
    const p = S.profile;
    for (const [key, label, kws] of SECTORS) {
      if (kws.some((k) => has(n, k))) { if (p.sector !== key) { p.sector = key; p.sectorLabel = label; p.pitched = false; } break; }
    }
    const team = n.match(/ (\d{1,3}) (?:empleados?|empleadas?|trabajador(?:es|as)?|personas|profesionales|companer[oa]s|chic[oa]s|esteticistas|peluquer[oa]s) /) || n.match(/ somos (\d{1,3}) /);
    if (team) p.team = Number(team[1]);
    if (/ (solo yo|yo sola|yo solo|trabajo sola|trabajo solo|autonomo|autonoma|freelance) /.test(n)) p.team = 1;
    const sedes = n.match(/ (\d{1,2}) (?:sedes?|locales?|centros?|sucursales?|tiendas?|clinicas?|salones?) /);
    if (sedes) p.sedes = Number(sedes[1]);
    const name = raw.match(/\bme llamo\s+([A-Za-zÁÉÍÓÚÑáéíóúñ]{2,20})/i);
    if (name) p.name = cap(name[1]);
    persist();
  }

  /* Respuestas ------------------------------------------------------------ */
  const priceTxt = (v) => (v ? `cuesta **${v}**` : 'tiene un precio que depende de tu negocio');
  const trialTxt = `**${DAYS} días gratis**, sin tarjeta y sin permanencia`;
  const stores = () => `[Google Play](${CONFIG.playStore}) · [App Store](${CONFIG.appStore}) · [APK para Android](${CONFIG.apk})`;
  const teamChips = () => [{ label: 'Solo yo', act: 'team:1' }, { label: '2 a 5', act: 'team:3' }, { label: '6 a 15', act: 'team:10' }, { label: 'Más de 15', act: 'team:20' }];

  const R = {
    saludo: () => (CONSUMER
      ? [`¡Hola${S.profile.name ? `, ${S.profile.name}` : ''}! ¿Quieres reservar una cita o tienes un negocio?`, [C.reservar, C.descargar, C.negocio]]
      : [`¡Hola${S.profile.name ? `, ${S.profile.name}` : ''}! ¿Qué tipo de negocio tienes? Así te cuento exactamente cómo te ayudaría Bookmy.`, sectorChips()]),
    que_es: () => ['**Bookmy no es solo una app de reservas: es el sistema que organiza y hace crecer tu negocio.** En un mismo panel tienes:\n- Reservas online 24/7 con confirmación automática\n- CRM con la ficha y el historial de cada cliente\n- Cobros, facturación e inventario\n- Equipo, horarios y varias sedes\n- Estadísticas en tiempo real y asistente con IA\n\n¿Qué tipo de negocio tienes? Te cuento cómo lo usarías tú.', sectorChips()],
    sector: () => {
      S.profile.pitched = true;
      const key = S.profile.sector || 'servicios';
      return [`${PITCH[key]}\n\n¿Cuántas personas sois en el equipo? Con eso te digo qué plan te conviene.`, teamChips()];
    },
    precio: () => [`Los planes son del CRM, para tu negocio. Tienes dos ([Plan Basic](plan-basic.html) y [Plan Pro](plan-pro.html)):\n- **Plan Basic**: reservas online, agenda 24/7, confirmaciones automáticas y perfil público. ${cap(priceTxt(CONFIG.basicPrice))}.\n- **Plan Pro**: todo el sistema (CRM, cobros, equipo, inventario, sedes, estadísticas e IA). ${cap(priceTxt(CONFIG.proPrice))}.\n\nLos dos se pueden probar ${trialTxt}. ¿Te digo cuál te sale más a cuenta?`, [C.recomendar, C.trial, C.demo]],
    planes: () => R.precio(),
    prueba: () => [`Puedes probar el **Plan Basic** o el **Plan Pro** ${trialTxt}. Eliges el plan en el alta y, al terminar, decides si sigues. Sin cargos sorpresa. ¿Empezamos?`, [C.trial, C.basic, C.demo]],
    permanencia: () => [`**Sin permanencia.** No te atas a nada, y la prueba es de ${DAYS} días sin tarjeta. Si en algún momento necesitas ayuda con tu suscripción, el equipo te atiende en [contacto@bookmy.es](mailto:contacto@bookmy.es).`, [C.trial, C.planes]],
    caro: () => [`Te entiendo: cada euro cuenta. Haz esta cuenta: ¿cuánto vale una cita que no se presenta en tu negocio? Si Bookmy te evita unas pocas al mes, la inversión se recupera rápido. Y puedes probar el plan que quieras ${trialTxt}. ¿Lo calculamos con tus números?`, [C.roi, C.basic, C.trial]],
    ausencias: () => ['Las citas que no se presentan son dinero que no vuelve. Bookmy envía **confirmaciones y recordatorios automáticos**, y en el Plan Pro tienes **reglas de disponibilidad y reprogramaciones sin fricciones**. ¿Calculamos cuánto te están costando hoy? Son 4 datos.', [C.roi, C.planes]],
    reservas: () => (CONSUMER
      ? R.reservar()
      : ['Tus clientes reservan **24/7** desde tu perfil público o la app: eligen servicio, fecha y profesional, y reciben **confirmación al instante**. Tú ves la agenda actualizada en tiempo real, sin llamadas ni mensajes cruzados.', [C.roi, C.recomendar, C.funciona]]),
    reservar: () => [`Reservar es muy fácil:\n- **1.** Descarga la app Bookmy (es gratis)\n- **2.** Busca tu centro y elige servicio\n- **3.** Elige especialista, día y hora\n- **4.** Paga online o en el local, como prefieras\n\nRecibes la confirmación al instante y un recordatorio antes de tu cita. ${stores()}`, [C.descargar, C.negocio]],
    cancelar: () => ['Desde **«Mis reservas»** en tu perfil puedes cambiar o cancelar tu cita, sin coste, siempre que lo hagas con antelación. El hueco queda libre para otra persona.', [C.reservar, C.descargar]],
    gratis_app: () => [`Sí: **la app Bookmy es gratis**. Solo pagas el servicio que reservas, online o en el local. ${stores()}`, [C.reservar, C.negocio]],
    descargar: () => [`Descarga **Bookmy gratis**:\n- ${stores()}\n\nEl APK es para móviles Android sin Google Play: tu móvil te pedirá permiso para instalarlo.`, CONSUMER ? [C.reservar, C.negocio] : [C.trial, C.que_es]],
    apk: () => [`Puedes instalar Bookmy en Android con el archivo APK: [descargar el APK](${CONFIG.apk}). Al abrirlo, tu móvil te pedirá permiso para instalar apps de esta fuente. También la tienes en [Google Play](${CONFIG.playStore}) y en [App Store](${CONFIG.appStore}).`, CONSUMER ? [C.reservar, C.negocio] : [C.trial, C.que_es]],
    empresas_app: () => [`Con **Bookmy para empresas** tu negocio aparece en la app: tus clientes te encuentran, reservan y pagan en segundos, y tú gestionas las citas desde el móvil. Para darte de alta necesitas una cuenta del CRM (Plan Basic o Plan Pro), con ${trialTxt}. [Así funciona](app-empresas.html).`, [C.recomendar, C.trial, C.demo]],
    crm: () => ['El **CRM de Bookmy** guarda la ficha de cada cliente: visitas, servicios, preferencias y consumo. Sabes quién lleva tiempo sin venir, quién gasta más y qué ofrecerle. Con la IA puedes **recuperar clientes inactivos** con mensajes personalizados. Está en el **Plan Pro**.', [C.trial, C.ia, C.recomendar]],
    pagos: () => ['Con el **Plan Pro** cobras **online o en el local** y tienes la **trazabilidad de cada transacción**, junto con la facturación, en la misma plataforma. Los pagos los procesan proveedores certificados: Bookmy no guarda los datos completos de las tarjetas.', [C.trial, C.recomendar]],
    equipo: () => ['En el **Plan Pro** asignas **roles, horarios y servicios** a cada persona del equipo, y cada una ve lo que le toca. ¿Cuántas personas sois?', teamChips()],
    sedes: () => ['El **Plan Pro** está pensado para negocios con varias sedes: las gestionas **todas desde un mismo panel**, cambias de sede en un clic y das a cada usuario acceso a la suya.', [C.trial, C.demo]],
    stock: () => ['El **control de inventario** del Plan Pro mantiene el stock de productos e insumos **sincronizado con cada reserva o venta**, para que no te quedes sin material a mitad de semana.', [C.trial, C.recomendar]],
    estadisticas: () => ['Tu panel muestra en tiempo real **clientes, ingresos del mes, reservas y valoración media**, y las estadísticas te dicen qué servicios y profesionales rinden más. Decides con datos, no a ojo.', [C.trial, C.recomendar]],
    resenas: () => ['Bookmy reúne las **reseñas** de tus clientes y te enseña tu valoración media en el panel. Con la IA puedes pedir la reseña justo después del servicio, que es cuando el cliente está más contento.', [C.ia, C.trial]],
    comunicacion: () => ['Desde **Comunicación** hablas con tus clientes desde el propio panel, y con la IA puedes lanzar mensajes personalizados, por ejemplo a quien lleva semanas sin venir.', [C.ia, C.trial]],
    automatizar: () => ['Bookmy automatiza lo repetitivo: **confirmaciones, recordatorios y reprogramaciones**. Configuras las reglas una vez y el sistema trabaja solo, incluso en los días de más lío.', [C.roi, C.trial]],
    ia: () => ['El **asistente IA de Bookmy** atiende a tus clientes 24/7, reserva según tu disponibilidad real, **sugiere extras** según el historial de cada cliente, recupera clientes inactivos y te responde preguntas sobre tu negocio. [Descúbrelo aquí](asistente-ia.html).', [C.recomendar, C.trial, C.demo]],
    app: () => (CONSUMER
      ? [`La **app Bookmy** es gratis en iOS y Android: buscas tu centro, eliges servicio, especialista y hora, y pagas online o en el local. ${stores()}`, [C.reservar, C.negocio]]
      : [`Sí: **Bookmy está en iOS y Android**. Tus clientes la descargan gratis, te encuentran, eligen servicio, especialista y hora, y pagan online o en el local. Tú gestionas tus citas desde el móvil y todo lo demás en el panel. [App para empresas](app-empresas.html) · ${stores()}`, [C.trial, C.recomendar]]),
    seguridad: () => ['Tus datos están protegidos con **cifrado en tránsito, control de accesos y monitorización continua**. Los pagos los procesan proveedores certificados y **no vendemos tus datos**. Tienes los detalles en la [política de privacidad](privacidad.html).', [C.que_es, C.demo]],
    ya_uso: () => [`¡Genial, ya sabes lo que es tener agenda online! La diferencia es que Bookmy no se queda en la reserva: une **CRM, cobros, equipo, inventario, sedes, estadísticas e IA** en un mismo panel, así que dejas de saltar entre herramientas. Pruébalo ${DAYS} días en paralelo, sin tarjeta, y compara. ¿Quieres que el equipo te ayude con el cambio?`, [C.trial, C.demo]],
    tiempo: () => ['Justo para eso está hecho. Creas la cuenta en menos de un minuto, añades tus servicios y horarios, y compartes tu enlace de reservas. A partir de ahí, Bookmy trabaja solo. Y si prefieres, el equipo te acompaña en el alta.', [C.basic, C.demo, C.funciona]],
    whatsapp: () => ['Puedes seguir usando WhatsApp e Instagram: comparte allí tu **enlace de reservas de Bookmy** y tus clientes reservan solos, 24/7, sin idas y venidas de mensajes. Tú solo ves la cita confirmada en tu agenda.', [C.basic, C.roi]],
    idioma: () => ['La plataforma está disponible en **español e inglés**.', [C.que_es, C.recomendar]],
    quienes: () => ['Bookmy es una plataforma de gestión para negocios de servicios. Trabajamos con negocios de la **Costa del Sol** (Benalmádena, Fuengirola, Marbella, Málaga, Torremolinos) y de **Colombia** (Bogotá y Medellín). [Conócenos](quienes-somos.html).', [C.demo, C.que_es]],
    funciona: () => [`Empezar es muy fácil:\n- **1.** Crea tu cuenta (menos de un minuto)\n- **2.** Añade servicios, horarios y equipo\n- **3.** Comparte tu perfil de reservas\n- **4.** Activa recordatorios y deja que Bookmy trabaje\n\nLos primeros ${DAYS} días son gratis. [Ver el paso a paso](como-funciona.html). ¿Te recomiendo plan?`, [C.recomendar, C.basic, C.trial]],
    soporte: () => [`Si ya eres cliente, lo más rápido es hablar con soporte: [WhatsApp](${wa('Hola, soy cliente de Bookmy y necesito ayuda con mi cuenta.')}) o [${CONFIG.email}](mailto:${CONFIG.email}). Y aquí puedes [entrar a tu panel](${CONFIG.login}).`, [C.que_es]],
    gracias: () => ['¡A ti! Si quieres, estos son los siguientes pasos:', CONSUMER ? [C.descargar, C.negocio] : [C.trial, C.basic, C.demo]],
    despedida: () => [`¡Perfecto! Para cuando lo decidas: el **Plan Basic** y el **Plan Pro** tienen ${trialTxt}. Si me dejas tu email, el equipo te manda la información.`, [C.demo, C.trial]],
    fallback: () => (CONSUMER
      ? ['No quiero darte un dato incorrecto. Puedo explicarte cómo reservar, dónde descargar la app o, si tienes un negocio, cómo aparecer en ella. ¿Qué prefieres?', [C.reservar, C.descargar, C.negocio]]
      : ['Buena pregunta. No quiero darte un dato incorrecto, así que te propongo dos cosas: te paso con una persona del equipo o te cuento lo principal de Bookmy. ¿Qué prefieres?', [C.demo, C.que_es, C.planes]]),
  };

  /* Flujos guiados ------------------------------------------------------- */
  const val = (x) => (typeof x === 'function' ? x() : x);
  // País del cálculo: el que eligió en el flujo (o «otro país» + su moneda)
  const roiCountry = () => {
    const p = S.profile;
    const code = p.pais === 'otro' ? p.pais2 : p.pais;
    return MONEY ? MONEY.get(code || 'es') : { code: 'es', name: 'España', cur: 'EUR', curName: 'euros', chips: [15, 30, 50] };
  };
  const COUNTRY_CHIPS = () => {
    const main = ['es', 'mx', 'co', 'ar', 'cl', 'pe', 'ec', 'us'];
    const g = MONEY ? MONEY.guess() : 'es';
    const order = main.includes(g) ? [g, ...main.filter((c) => c !== g)] : main;
    return [...order.map((c) => [MONEY ? MONEY.get(c).name : c, c]), ['Otro país', 'otro']];
  };

  const FLOWS = {
    recomendar: {
      intro: 'Perfecto. Te recomiendo plan en 3 preguntas.',
      steps: [
        { key: 'team', q: '¿Cuántas personas atendéis en tu negocio?', opts: [['Solo yo', 1], ['2 a 5', 3], ['6 a 15', 10], ['Más de 15', 20]],
          parse: (n) => (/ (solo|sola|yo) /.test(n) ? 1 : firstNum(n)) },
        { key: 'sedes', q: '¿Cuántas sedes o locales tienes?', opts: [['1', 1], ['2 o 3', 2], ['4 o más', 4]], parse: (n) => firstNum(n) },
        { key: 'pain', q: '¿Qué quieres mejorar primero?', opts: [['Recibir reservas online', 'agenda'], ['Que no falten clientes', 'ausencias'], ['Cobros y facturación', 'cobros'], ['Equipo y sedes', 'equipo'], ['Vender más a mis clientes', 'ventas']],
          parse: (n) => (/ (falt|ausenc|no vien|recordat)/.test(n) ? 'ausencias' : / (cobr|factur|pago)/.test(n) ? 'cobros' : / (equipo|sede|emplead)/.test(n) ? 'equipo' : / (vend|ventas|ingres|factur)/.test(n) ? 'ventas' : / (reserv|agenda|cita)/.test(n) ? 'agenda' : null) },
      ],
      done: () => recommend(),
    },
    roi: {
      intro: 'Vamos a calcularlo con 4 datos rápidos. Primero, para hacer las cuentas en tu moneda:',
      steps: [
        { key: 'pais', q: '¿En qué país está tu negocio?', opts: COUNTRY_CHIPS,
          parse: (n, raw) => (/ otro /.test(n) && !(MONEY && MONEY.match(raw)) ? 'otro' : (MONEY ? MONEY.match(raw) : null)),
          retry: 'No he reconocido el país. Elige uno de la lista o escríbelo de otra forma, por ejemplo «Colombia» o «México».' },
        { key: 'pais2', q: '¿Cuál es tu país? Si lo prefieres, dime solo la moneda.', skip: () => S.profile.pais !== 'otro',
          opts: [['Euros (€)', 'eu'], ['Dólares (US$)', 'usd'], ['Venezuela', 've'], ['República Dominicana', 'do'], ['Guatemala', 'gt'], ['Costa Rica', 'cr']],
          parse: (n, raw) => (MONEY ? MONEY.match(raw) : null),
          retry: 'No lo he reconocido. Elige una opción o escribe tu país o tu moneda.' },
        { key: 'citas', q: '¿Cuántas citas atiendes a la semana, más o menos?', opts: [['20', 20], ['50', 50], ['100', 100], ['200', 200]], parse: (n) => firstNum(n) },
        { key: 'ticket', q: () => `¿Cuánto cobras de media por cita, en ${roiCountry().curName}?`,
          opts: () => roiCountry().chips.map((v) => [money(v, roiCountry().code), v]),
          parse: (n, raw) => (MONEY ? MONEY.parse(raw) : firstNum(n)) },
        { key: 'rate', q: 'De cada 10 citas, ¿cuántas se caen sin avisar o a última hora?', opts: [['Casi ninguna', 0.05], ['1', 0.1], ['2', 0.2], ['3 o más', 0.3]],
          parse: (n) => { if (/ (ninguna|casi ninguna) /.test(n)) return 0.05; const v = firstNum(n); if (v == null) return null; return n.includes('%') ? v / 100 : v <= 10 ? v / 10 : null; } },
      ],
      done: () => roiResult(),
    },
  };

  async function startFlow(name, fresh = false) {
    const f = FLOWS[name];
    if (!f) return;
    if (fresh && name === 'roi') ['pais', 'pais2', 'citas', 'ticket', 'rate'].forEach((k) => delete S.profile[k]);
    S.flow = { name, i: 0 };
    persist();
    await say(f.intro);
    await askStep();
  }

  async function askStep(again) {
    const f = FLOWS[S.flow.name];
    const answered = (st) => S.flow.name === 'recomendar' && S.profile[st.key] != null;
    while (S.flow.i < f.steps.length && (answered(f.steps[S.flow.i]) || f.steps[S.flow.i].skip?.())) S.flow.i += 1;
    if (S.flow.i >= f.steps.length) { S.flow = null; persist(); await f.done(); return; }
    const st = f.steps[S.flow.i];
    persist();
    await say(again && st.retry ? st.retry : val(st.q));
    chips(val(st.opts).map(([label, v]) => ({ label, val: v })));
  }

  async function flowAnswer(v) {
    const st = FLOWS[S.flow.name].steps[S.flow.i];
    S.profile[st.key] = v;
    S.flow.i += 1;
    persist();
    await askStep();
  }

  async function recommend() {
    const p = S.profile;
    const team = Number(p.team || 1);
    const sedes = Number(p.sedes || 1);
    const pro = !(team <= 1 && sedes <= 1 && (!p.pain || p.pain === 'agenda'));
    const why = [];
    if (pro) {
      if (team > 1) why.push('Equipo con roles, horarios y servicios por persona');
      if (sedes > 1) why.push('Todas tus sedes en un mismo panel');
      if (p.pain === 'ausencias') why.push('Recordatorios automáticos y reprogramaciones sin fricciones');
      if (p.pain === 'cobros') why.push('Cobros online o en local y facturación con trazabilidad');
      if (p.pain === 'ventas') why.push('CRM con el historial de cada cliente para venderle mejor');
      if (p.pain === 'equipo' && team <= 1) why.push('Administración de trabajadores y sedes');
      why.push('Estadísticas en tiempo real para decidir con datos');
    } else {
      why.push('Reservas online 24/7 desde tu perfil público', 'Confirmaciones automáticas', 'Gestión desde el móvil o la tablet', 'Puedes pasar a Pro cuando crezcas');
    }
    const list = why.slice(0, 4).map((w) => `<li>${esc(w)}</li>`).join('');
    const html = pro
      ? `<div class="ai-card__title">Plan Pro <span class="tag tag--dark">Recomendado</span></div>
         <ul class="checks">${list}</ul>
         <a class="btn btn--mint btn--block" href="${CONFIG.signupPro}" target="_blank" rel="noopener">Probar ${DAYS} días gratis</a>
         <small>Sin tarjeta · sin permanencia</small>`
      : `<div class="ai-card__title">Plan Basic <span class="tag">Recomendado</span></div>
         <ul class="checks">${list}</ul>
         <a class="btn btn--primary btn--block" href="${CONFIG.signupBasic}" target="_blank" rel="noopener">Probar ${DAYS} días gratis</a>
         <small>Sin tarjeta · sin permanencia</small>`;
    await say(pro
      ? `Con lo que me cuentas, te recomiendo el **Plan Pro**${p.sectorLabel ? ` para tu negocio de ${p.sectorLabel}` : ''}:`
      : 'Para empezar, el **Plan Basic** te va perfecto:');
    addCard(html, pro);
    await say(pro
      ? '¿Prefieres probarlo tú directamente o que alguien del equipo te lo enseñe con tu caso?'
      : `Pruébalo ${DAYS} días gratis y, cuando crezcas, puedes pasar a Pro. ¿Te ayudo con algo más?`);
    chips(pro ? [C.trial, C.demo, C.roi] : [C.basic, C.trial, C.roi]);
  }

  async function roiResult() {
    const p = S.profile;
    const c = roiCountry();
    const m = (v) => money(v, c.code);
    const lost = p.citas * 4.33 * p.ticket * p.rate;
    const back = lost / 3;
    await say(`Aquí tienes tu estimación, en ${c.curName}:`);
    addCard(`<div class="ai-card__title">Lo que pierdes cada mes</div>
      <div class="ai-card__big">${m(lost)}</div>
      <small>Por ${Math.round(p.citas * 4.33 * p.rate)} citas al mes que no se presentan (${p.citas} citas/semana · ${m(p.ticket)} de media).</small>
      <hr style="border:0;border-top:1px solid rgba(255,255,255,.1)">
      <div>Si los recordatorios y la reprogramación evitan solo <b>1 de cada 3</b>, recuperas <b>${m(back)} al mes</b> · <b>${m(back * 12)} al año</b>.</div>
      <small>Estimación orientativa en ${esc(c.curName)} (${esc(c.cur)})${c.code === 'eu' || c.code === 'usd' ? '' : ` · ${esc(c.name)}`}. Cada negocio es distinto.</small>`, true);
    await say(`Es dinero que ya estás generando y se te escapa. Lo más rápido para comprobarlo: **prueba el Plan Pro ${DAYS} días gratis**, sin tarjeta, y activa los recordatorios hoy.`);
    chips([C.trial, C.demo, C.recomendar]);
  }

  /* Captación de contactos (con consentimiento) ------------------------- */
  const TIPOS = ['Salud', 'Estética', 'Construcción', 'Tecnología', 'Servicios', 'Otros'];
  const TIPO_DE = { estetica: 'Estética', peluqueria: 'Estética', salud: 'Salud', bienestar: 'Servicios', tatuajes: 'Servicios', construccion: 'Construcción', tecnologia: 'Tecnología', servicios: 'Servicios' };

  function summary(lead) {
    const p = S.profile;
    const bits = [`Hola Bookmy, soy ${lead.nombre}${lead.tipo ? ` (${lead.tipo})` : ''}. Me interesa Bookmy.`];
    if (p.team) bits.push(`Equipo: ${p.team === 1 ? 'solo yo' : `${p.team} personas aprox.`}.`);
    if (p.sedes) bits.push(`Sedes: ${p.sedes}.`);
    if (p.pain) bits.push(`Prioridad: ${p.pain}.`);
    if (lead.email || lead.telefono) bits.push(`Contacto: ${[lead.email, lead.telefono].filter(Boolean).join(' · ')}.`);
    return bits.join(' ');
  }

  async function leadFlow(prefill = {}) {
    await say(S.lead
      ? 'Ya tenemos tus datos y el equipo te escribirá en breve. Si quieres, añade otra forma de contacto:'
      : '¡Claro! Déjame tus datos y una persona del equipo te contacta en breve para enseñarte Bookmy con tu caso.');
    const uidf = Date.now().toString(36);
    const tipo = TIPO_DE[S.profile.sector] || '';
    const card = addCard(`
      <form class="ai-form" novalidate>
        <div class="ai-card__title">Hablar con el equipo</div>
        <label class="sr-only" for="ln-${uidf}">Nombre</label>
        <input class="input" id="ln-${uidf}" name="nombre" placeholder="Tu nombre" autocomplete="name" value="${esc(S.profile.name || prefill.nombre || '')}">
        <label class="sr-only" for="le-${uidf}">Email</label>
        <input class="input" id="le-${uidf}" name="email" type="email" placeholder="Email" autocomplete="email" value="${esc(prefill.email || '')}">
        <label class="sr-only" for="lt-${uidf}">Teléfono</label>
        <input class="input" id="lt-${uidf}" name="telefono" type="tel" placeholder="Teléfono (opcional)" autocomplete="tel" value="${esc(prefill.telefono || '')}">
        <label class="sr-only" for="ls-${uidf}">Tipo de empresa</label>
        <select class="input" id="ls-${uidf}" name="tipo">
          <option value="">Tipo de empresa</option>
          ${TIPOS.map((t) => `<option${t === tipo ? ' selected' : ''}>${t}</option>`).join('')}
        </select>
        <label class="ai-consent"><input type="checkbox" name="ok"><span>Acepto que Bookmy use estos datos para responder a mi solicitud. Puedes ejercer tus derechos de acceso, rectificación o supresión. Más info en la <a href="privacidad.html#asistente" target="_blank" rel="noopener">política de privacidad</a>.</span></label>
        <p class="ai-form__err" hidden></p>
        <button class="btn btn--primary btn--block" type="submit">Quiero que me contactéis</button>
      </form>`, false, false);
    const f = $('form', card);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const lead = {
        nombre: f.nombre.value.trim(), email: f.email.value.trim(), telefono: f.telefono.value.trim(), tipo: f.tipo.value,
      };
      const err = $('.ai-form__err', f);
      const fail = (m) => { err.textContent = m; err.hidden = false; };
      if (lead.nombre.length < 2) return fail('Dinos tu nombre.');
      if (!/^\S+@\S+\.\S+$/.test(lead.email) && lead.telefono.replace(/\D/g, '').length < 7) return fail('Déjanos un email o un teléfono válido.');
      if (!f.ok.checked) return fail('Necesitamos tu consentimiento para contactarte.');
      err.hidden = true;
      S.profile.name = S.profile.name || lead.nombre.split(' ')[0];
      const btn = $('button[type="submit"]', f);
      btn.disabled = true;
      btn.textContent = 'Enviando…';
      let sent = false;
      if (CONFIG.leadEndpoint) {
        try {
          const r = await fetch(CONFIG.leadEndpoint, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...lead, consentimiento: true, perfil: S.profile, pagina: page, resumen: summary(lead), web: '' }),
          });
          sent = r.ok;
        } catch { sent = false; }
      }
      card.remove();
      S.lead = true;
      persist();
      if (sent) {
        await say(`¡Gracias, ${lead.nombre.split(' ')[0]}! Lo hemos recibido y el equipo te contactará en breve. Mientras tanto, puedes [empezar tu prueba de ${DAYS} días](crear-cuenta.html) hoy mismo.`);
        chips([C.trial, C.basic]);
      } else {
        await say(`¡Gracias, ${lead.nombre.split(' ')[0]}! Último paso: envíanos tu solicitud por el canal que prefieras y te respondemos enseguida.`);
        const text = summary(lead);
        addCard(`<div class="ai-card__title">Envía tu solicitud</div>
          <a class="btn btn--primary btn--block" href="${wa(text)}" target="_blank" rel="noopener"><i class="i i-message-circle" aria-hidden="true"></i>Enviar por WhatsApp</a>
          <a class="btn btn--outline btn--block" href="mailto:${CONFIG.email}?subject=${encodeURIComponent('Quiero conocer Bookmy')}&body=${encodeURIComponent(text)}"><i class="i i-mail" aria-hidden="true"></i>Enviar por email</a>`, false);
      }
    });
  }

  /* IA real (opcional) --------------------------------------------------- */
  async function askAI() {
    const t = showTyping();
    try {
      const history = S.msgs.filter((m) => m.from === 'user' || m.from === 'bot').slice(-14)
        .map((m) => ({ role: m.from === 'user' ? 'user' : 'assistant', content: m.text }));
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 25000);
      const r = await fetch(CONFIG.endpoint, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctl.signal,
        body: JSON.stringify({ messages: history, page, profile: S.profile }),
      });
      clearTimeout(timer);
      if (!r.ok) throw new Error(String(r.status));
      const data = await r.json();
      if (!data || typeof data.reply !== 'string' || !data.reply.trim()) throw new Error('vacío');
      t.remove();
      addMsg('bot', data.reply.trim());
      return true;
    } catch {
      t.remove();
      return false;
    }
  }

  /* Conversación --------------------------------------------------------- */
  let busy = false;
  const setBusy = (v) => { busy = v; send.disabled = v || !input.value.trim(); };

  async function respond(intent) {
    if (intent === 'demo') return leadFlow();
    if (intent === 'recomendar') return startFlow('recomendar');
    if (intent === 'roi') return startFlow('roi', true);
    const [text, next] = (R[intent] || R.fallback)();
    await say(text);
    if (next?.length) chips(next);
  }

  async function nudge() {
    if (CONSUMER || S.turns < 4 || S.lead || S.nudged || S.flow) return;
    S.nudged = true;
    persist();
    await say('Por cierto: ¿quieres una recomendación a tu medida? Son 3 preguntas y te digo qué plan te conviene.');
    chips([C.recomendar, C.demo]);
  }

  async function onUser(text) {
    if (busy || !text) return;
    setBusy(true);
    clearChips();
    addMsg('user', text);
    S.turns += 1;
    const n = norm(text);
    extract(text, n);

    if (S.flow) {
      const st = FLOWS[S.flow.name].steps[S.flow.i];
      const v = st?.parse(n, text);
      if (v != null && !Number.isNaN(v)) { await flowAnswer(v); setBusy(false); return; }
      // Respuesta no reconocida: si no es otra pregunta, se repite el paso
      if (st?.retry && detect(n) === 'fallback') { await askStep(true); setBusy(false); return; }
      S.flow = null;
      persist();
    }

    const email = text.match(/\S+@\S+\.\S+/);
    const phone = text.match(/(?:\+?\d[\d\s]{7,}\d)/);
    if (email || phone) {
      await leadFlow({ email: email?.[0] || '', telefono: phone?.[0] || '' });
      setBusy(false);
      return;
    }

    const intent = detect(n);
    const guided = ['demo', 'recomendar', 'roi'].includes(intent);
    if (AI && !guided) {
      const ok = await askAI();
      if (ok) {
        const [, next] = (R[intent] || R.fallback)();
        if (next?.length) chips(next);
        await nudge();
        setBusy(false);
        return;
      }
    }
    await respond(intent);
    await nudge();
    setBusy(false);
  }

  async function onAct(act, label) {
    if (busy) return;
    setBusy(true);
    clearChips();
    if (label) addMsg('user', label);
    if (act.startsWith('flow:')) await startFlow(act.slice(5), true);
    else if (act.startsWith('sector:')) {
      const key = act.slice(7);
      const found = SECTORS.find(([k]) => k === key);
      S.profile.sector = key;
      S.profile.sectorLabel = found ? found[1] : key;
      S.profile.pitched = false;
      await respond('sector');
    } else if (act.startsWith('team:')) {
      S.profile.team = Number(act.slice(5));
      persist();
      S.flow = { name: 'recomendar', i: 0 };
      await askStep();
    } else await respond(act);
    setBusy(false);
  }

  log.addEventListener('click', async (e) => {
    const chip = e.target.closest('.ai-chip');
    if (!chip) return;
    const c = S.chips[Number(chip.dataset.idx)];
    if (!c) return;
    if (c.href) {
      clearChips();
      addMsg('user', c.label);
      await say('¡Perfecto! Te lo he abierto en una pestaña nueva. Si te surge cualquier duda, sigo aquí.');
      return;
    }
    if (c.val !== undefined && S.flow) {
      if (busy) return;
      setBusy(true);
      clearChips();
      addMsg('user', c.label);
      await flowAnswer(c.val);
      setBusy(false);
      return;
    }
    if (c.act) await onAct(c.act, c.label);
  });

  /* Abrir, cerrar, sugerencias -------------------------------------------- */
  const mqSmall = matchMedia('(max-width: 560px)');
  let restored = false;

  function restore() {
    if (restored) return;
    restored = true;
    addDisclaimer();
    S.msgs.forEach(renderMsg);
    if (S.chips?.length) renderChips(S.chips);
    scrollDown(true);
  }

  async function open(action) {
    restore();
    hideTeaser();
    dot.hidden = true;
    panel.classList.add('is-open');
    panel.inert = false;
    panel.setAttribute('aria-hidden', 'false');
    launcher.setAttribute('aria-expanded', 'true');
    document.body.classList.add('ai-open');
    if (mqSmall.matches) document.body.classList.add('is-locked');
    if (matchMedia('(pointer: fine)').matches) setTimeout(() => input.focus({ preventScroll: true }), 250);
    const first = !S.opened && !S.msgs.length;
    S.opened = true;
    persist();
    if (first) {
      if (action) {
        setBusy(true);
        await say('¡Hola! Soy el asistente de Bookmy.');
        setBusy(false);
      } else {
        setBusy(true);
        if (CONSUMER) {
          await say('¡Hola! Soy el asistente de Bookmy. Te ayudo a **reservar tu cita**, a **descargar la app** o, si tienes un negocio, a **aparecer en ella**. ¿Por dónde empezamos?');
          chips([C.reservar, C.descargar, C.negocio, C.demo]);
        } else {
          await say('¡Hola! Soy el asistente de Bookmy. Te ayudo a **elegir plan**, a **calcular lo que puedes recuperar** con Bookmy o a resolver cualquier duda. ¿Por dónde empezamos?');
          chips([C.que_es, C.recomendar, C.roi, C.planes, C.demo]);
        }
        setBusy(false);
      }
    }
    if (action) {
      if (action.ask) await onUser(action.ask);
      else if (action.act) await onAct(action.act, action.label);
    }
  }

  function close() {
    panel.classList.remove('is-open');
    panel.inert = true;
    panel.setAttribute('aria-hidden', 'true');
    launcher.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('ai-open', 'is-locked');
    launcher.focus({ preventScroll: true });
  }

  function reset() {
    S = blank();
    S.opened = true;
    persist();
    log.innerHTML = '';
    restored = true;
    addDisclaimer();
    busy = false;
    (async () => {
      setBusy(true);
      await say('Empezamos de nuevo. ¿En qué te ayudo?');
      chips(CONSUMER ? [C.reservar, C.descargar, C.negocio, C.demo] : [C.que_es, C.recomendar, C.roi, C.planes, C.demo]);
      setBusy(false);
    })();
  }

  launcher.addEventListener('click', () => open());
  panel.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ai]');
    if (!b) return;
    if (b.dataset.ai === 'close') close();
    if (b.dataset.ai === 'reset') reset();
  });
  panel.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });

  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 120)}px`;
    send.disabled = busy || !input.value.trim();
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
  });
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim().slice(0, 600);
    if (!text || busy) return;
    input.value = '';
    input.style.height = 'auto';
    onUser(text);
  });

  /* Sugerencia proactiva según la página */
  const TEASERS = {
    crm: ['¿Cuánto dinero pierdes por citas que no se presentan? Te lo calculo en tu moneda en 20 segundos.', { act: 'flow:roi', label: 'Quiero calcularlo' }],
    app: ['¿Te ayudo a reservar tu primera cita con Bookmy?', { act: 'reservar', label: '¿Cómo reservo una cita?' }],
    'app-empresas': ['¿Quieres que tu negocio aparezca en la app? Te cuento cómo en un minuto.', { act: 'empresas_app', label: 'Quiero aparecer en la app' }],
    'plan-basic': ['¿Basic te basta o te conviene Pro? Te lo digo en 3 preguntas.', { act: 'flow:recomendar', label: 'Recomiéndame un plan' }],
    'plan-pro': ['¿Cuánto recuperarías con Pro? Lo calculamos con tus números, en tu moneda.', { act: 'flow:roi', label: 'Quiero calcularlo' }],
    planes: ['¿Basic o Pro? Te digo cuál te conviene en 3 preguntas.', { act: 'flow:recomendar', label: 'Recomiéndame un plan' }],
    'como-funciona': ['¿Lo vemos para tu negocio? Te explico cómo empezar en tu caso.', { act: 'funciona', label: '¿Cómo empiezo?' }],
    'asistente-ia': ['Ponme a prueba: pregúntame lo que te preguntaría un cliente.', { act: 'ia', label: '¿Qué puede hacer la IA por mi negocio?' }],
    'quienes-somos': ['¿Hablamos? Te pongo en contacto con el equipo en un momento.', { act: 'demo', label: 'Quiero hablar con el equipo' }],
  };
  let teaserAction = null;
  function showTeaser() {
    const t = TEASERS[page];
    if (!t || S.opened || document.body.classList.contains('ai-open')) return;
    try { if (sessionStorage.getItem('bookmy_ai_teaser')) return; } catch { /* nada */ }
    if (mqSmall.matches && document.body.classList.contains('cc-visible')) {
      document.addEventListener('bookmy:consent', () => setTimeout(showTeaser, 2500), { once: true });
      return;
    }
    teaserAction = t[1];
    $('.ai-teaser__txt', teaser).textContent = t[0];
    teaser.classList.add('is-visible');
    dot.hidden = false;
  }
  function hideTeaser(remember) {
    teaser.classList.remove('is-visible');
    if (remember) { try { sessionStorage.setItem('bookmy_ai_teaser', '1'); } catch { /* nada */ } }
  }
  $('.ai-teaser__close', teaser).addEventListener('click', () => { hideTeaser(true); dot.hidden = true; });
  $('.ai-teaser__txt', teaser).addEventListener('click', () => { hideTeaser(true); open(teaserAction); });
  setTimeout(showTeaser, CONFIG.teaserDelay);

  /* Botones de la web que abren el asistente */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-assistant-open],[data-assistant-ask],[data-assistant-flow]');
    if (!b) return;
    e.preventDefault();
    if (b.dataset.assistantAsk) open({ ask: b.dataset.assistantAsk });
    else if (b.dataset.assistantFlow) open({ act: `flow:${b.dataset.assistantFlow}`, label: b.dataset.assistantLabel || b.textContent.trim() });
    else open();
  });

  window.BookmyAssistant = {
    open: () => open(),
    ask: (text) => open({ ask: String(text) }),
    flow: (name) => open({ act: `flow:${name}` }),
    close,
  };
})();
