/* ==========================================================================
   Bookmy · cookies.js
   Aviso y panel de preferencias de cookies (RGPD, LSSI art. 22.2 y guía de
   la AEPD): "Aceptar" y "Rechazar" con el mismo peso visual en la primera
   capa, consentimiento por categorías, caducidad a los 12 meses y bloqueo
   previo de scripts no esenciales.

   Para bloquear un script hasta que haya consentimiento:
     <script type="text/plain" data-consent="analytics" data-src="https://..."></script>
   Categorías: functional · analytics · marketing
   API: window.BookmyConsent.has('analytics') · .open() · .get()
   Evento: document.addEventListener('bookmy:consent', e => e.detail)
   ========================================================================== */
(() => {
  'use strict';

  const KEY = 'bookmy_consent';
  const VERSION = 1;                      // súbelo si cambian las categorías: se vuelve a pedir
  const MAX_AGE = 365 * 24 * 60 * 60 * 1000; // 12 meses
  const POLICY_URL = 'cookies.html';

  const CATS = [
    { id: 'necessary', name: 'Técnicas y necesarias', locked: true,
      desc: 'Imprescindibles para que la web funcione: seguridad, navegación y recordar tu elección sobre cookies. No requieren consentimiento.' },
    { id: 'functional', name: 'Funcionales',
      desc: 'Recuerdan tus preferencias, como la conversación con el asistente entre visitas o el plan que estabas consultando.' },
    { id: 'analytics', name: 'Analíticas',
      desc: 'Nos ayudan a entender de forma agregada cómo se usa la web (páginas vistas, origen de las visitas) para mejorarla.' },
    { id: 'marketing', name: 'Marketing',
      desc: 'Permiten medir campañas y mostrarte contenido de Bookmy relevante en otras plataformas.' },
  ];

  const read = () => {
    try {
      const v = JSON.parse(localStorage.getItem(KEY));
      if (!v || v.v !== VERSION || Date.now() - v.ts > MAX_AGE) return null;
      return v;
    } catch { return null; }
  };
  const write = (choices) => {
    const v = { v: VERSION, ts: Date.now(), choices };
    try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* modo privado: solo en memoria */ }
    return v;
  };

  let state = read();
  const has = (cat) => cat === 'necessary' || Boolean(state?.choices?.[cat]);

  /* Activa los scripts bloqueados de las categorías aceptadas */
  const activateScripts = () => {
    document.querySelectorAll('script[type="text/plain"][data-consent]').forEach((old) => {
      if (!has(old.dataset.consent)) return;
      const s = document.createElement('script');
      Array.from(old.attributes).forEach((a) => {
        if (!['type', 'data-consent', 'data-src'].includes(a.name)) s.setAttribute(a.name, a.value);
      });
      if (old.dataset.src) s.src = old.dataset.src; else s.textContent = old.textContent;
      old.replaceWith(s);
    });
  };

  const apply = () => {
    activateScripts();
    if (typeof window.gtag === 'function') {
      const g = (ok) => (ok ? 'granted' : 'denied');
      window.gtag('consent', 'update', {
        analytics_storage: g(has('analytics')),
        ad_storage: g(has('marketing')),
        ad_user_data: g(has('marketing')),
        ad_personalization: g(has('marketing')),
        functionality_storage: g(has('functional')),
      });
    }
    document.dispatchEvent(new CustomEvent('bookmy:consent', { detail: { ...(state?.choices || {}) } }));
  };

  /* Primera capa ---------------------------------------------------------- */
  let banner;
  let dialog;

  const buildBanner = () => {
    banner = document.createElement('section');
    banner.className = 'cc';
    banner.setAttribute('aria-label', 'Aviso de cookies');
    banner.innerHTML = `
      <div class="cc__head">
        <span class="ib ib--sm" aria-hidden="true"><i class="i i-cookie"></i></span>
        <h2>Tu privacidad, tus reglas</h2>
      </div>
      <p>Usamos cookies propias y de terceros para que la web funcione, recordar tus preferencias, medir el uso y, si lo aceptas, personalizar publicidad. Puedes aceptarlas, rechazarlas o elegir cuáles. <a href="${POLICY_URL}">Política de cookies</a>.</p>
      <div class="cc__actions">
        <button type="button" class="btn btn--dark" data-cc="reject">Rechazar todas</button>
        <button type="button" class="btn btn--dark" data-cc="accept">Aceptar todas</button>
      </div>
      <button type="button" class="cc__config" data-cc="config"><i class="i i-sliders" aria-hidden="true"></i>Configurar</button>`;
    banner.addEventListener('click', onClick);
    document.body.append(banner);
  };

  const showBanner = () => {
    if (!banner) buildBanner();
    requestAnimationFrame(() => requestAnimationFrame(() => banner.classList.add('is-visible')));
    document.body.classList.add('cc-visible');
  };
  const hideBanner = () => {
    banner?.classList.remove('is-visible');
    document.body.classList.remove('cc-visible');
  };

  /* Segunda capa (panel) -------------------------------------------------- */
  const buildDialog = () => {
    dialog = document.createElement('dialog');
    dialog.className = 'cc-dialog';
    dialog.setAttribute('aria-labelledby', 'cc-title');
    dialog.innerHTML = `
      <div class="cc-dialog__head">
        <div>
          <h2 id="cc-title">Preferencias de cookies</h2>
          <p>Elige qué categorías permites. Puedes cambiarlo cuando quieras desde «Configurar cookies», en el pie de página.</p>
        </div>
        <button type="button" class="cc-dialog__close" data-cc="close" aria-label="Cerrar"><i class="i i-x" aria-hidden="true"></i></button>
      </div>
      <div class="cc-dialog__body">
        ${CATS.map((c) => `
          <div class="cc-opt">
            <div class="cc-opt__top">
              ${c.locked
                ? `<span>${c.name}</span><span class="cc-opt__always">Siempre activas</span>`
                : `<label for="cc-${c.id}">${c.name}</label>
                   <span class="switch"><input type="checkbox" role="switch" id="cc-${c.id}" data-cat="${c.id}"><span></span></span>`}
            </div>
            <p>${c.desc}</p>
          </div>`).join('')}
        <p class="small muted" style="padding:14px 0 6px">Detalle de cada cookie, proveedor y duración en la <a href="${POLICY_URL}" style="text-decoration:underline">política de cookies</a>.</p>
      </div>
      <div class="cc-dialog__foot">
        <button type="button" class="btn btn--outline" data-cc="reject">Rechazar todas</button>
        <button type="button" class="btn btn--outline" data-cc="accept">Aceptar todas</button>
        <button type="button" class="btn btn--dark" data-cc="save">Guardar selección</button>
      </div>`;
    dialog.addEventListener('click', (e) => {
      if (e.target === dialog) { dialog.close(); return; } // clic en el fondo
      onClick(e);
    });
    document.body.append(dialog);
  };

  const openDialog = () => {
    if (!dialog) buildDialog();
    dialog.querySelectorAll('[data-cat]').forEach((i) => { i.checked = has(i.dataset.cat); });
    if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.setAttribute('open', '');
  };

  const save = (choices) => {
    state = write(choices);
    hideBanner();
    if (dialog?.open) dialog.close();
    apply();
  };

  function onClick(e) {
    const btn = e.target.closest('[data-cc]');
    if (!btn) return;
    const act = btn.dataset.cc;
    if (act === 'accept') save({ functional: true, analytics: true, marketing: true });
    else if (act === 'reject') save({ functional: false, analytics: false, marketing: false });
    else if (act === 'config') openDialog();
    else if (act === 'close') dialog.close();
    else if (act === 'save') {
      const choices = {};
      dialog.querySelectorAll('[data-cat]').forEach((i) => { choices[i.dataset.cat] = i.checked; });
      save(choices);
    }
  }

  /* Enlaces "Configurar cookies" en cualquier parte de la web */
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-cookie-settings]');
    if (!t) return;
    e.preventDefault();
    openDialog();
  });

  window.BookmyConsent = {
    has,
    open: openDialog,
    get: () => (state ? { ...state.choices, fecha: new Date(state.ts).toISOString() } : null),
  };

  const init = () => {
    if (state) apply(); else showBanner();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
