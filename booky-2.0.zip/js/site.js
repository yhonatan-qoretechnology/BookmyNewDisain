/* ==========================================================================
   Bookmy · site.js — Motor de las páginas internas (diseño Inmersivo 3D)
   Sin librerías. Un solo bucle por fotograma para todo lo que depende del
   scroll: escenas fijadas, cartas apiladas, palabras que se iluminan,
   imágenes que crecen y se apagan, marquesinas con inercia y cabecera que
   se esconde al bajar.
   Atributos que entiende:
     data-reveal[="fade|scale|blur"]  aparece al entrar en pantalla
     data-split                       titular que sube palabra a palabra
     data-scrub                       párrafo que se ilumina con el scroll
     data-scene="nombre"              escena fijada; expone --p (0..1)
     data-stack                       cartas que se apilan
     data-zoom                        crece al entrar y se apaga al salir
     data-tilt                        inclinación 3D que sigue al puntero
     data-marquee="1|-1"              cinta infinita (dirección)
     data-carousel                    testimonios con flechas
     data-count, data-tabs, .faq, data-roi, data-chat-demo,
     data-newsletter, data-toc        (igual que antes)
     canvas[data-sculpture]           escultura de partículas (particles.js)
   ========================================================================== */
(() => {
  'use strict';

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const easeOut = (t) => 1 - Math.pow(1 - t, 3);
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const P = window.BookmyParticles;
  const root = document.documentElement;
  root.classList.add('js', 'site-ready');

  $$('[data-year]').forEach((el) => { el.textContent = String(new Date().getFullYear()); });

  /* Fondo y esculturas de partículas ------------------------------------ */
  if (P) {
    const bg = $('.bg__stars');
    if (bg) { try { P.field(bg, { count: innerWidth < 700 ? 70 : 150, speed: 0.03 }); } catch (e) { /* sin fondo */ } }
    $$('canvas[data-sculpture]').forEach((cv) => {
      try {
        const d = cv.dataset;
        let markers = [];
        try { markers = d.markers ? JSON.parse(d.markers) : []; } catch (e) { markers = []; }
        cv.bmSculpture = P.sculpture(cv, {
          shapes: d.sculpture.split(','),
          spin: d.spin ? Number(d.spin) : 0.3,
          swing: d.swing !== undefined ? Number(d.swing) : 0,
          extent: d.extent ? Number(d.extent) : 1.35,
          size: d.size ? Number(d.size) : 1.2,
          tilt: d.tilt ? Number(d.tilt) : 0.25,
          count: d.count ? Number(d.count) : undefined,
          repel: d.repel !== 'false',
          markers,
        });
        if (d.turn) cv.bmSculpture.turn(Number(d.turn));
      } catch (e) { /* sin escultura */ }
    });
  }

  /* Cabecera: se esconde al bajar y vuelve al subir --------------------- */
  const header = $('.site-header');
  const ddOpen = () => Boolean($('.nav__dd.is-open'));
  let lastY = scrollY;
  function updateHeader(y) {
    if (!header) return;
    const dy = y - lastY;
    if (y < 140 || document.body.classList.contains('menu-open') || ddOpen() || header.contains(document.activeElement)) {
      header.classList.remove('is-hidden');
    } else if (dy > 6) header.classList.add('is-hidden');
    else if (dy < -6) header.classList.remove('is-hidden');
    if (Math.abs(dy) > 6 || y < 140) lastY = y;
  }
  header?.addEventListener('focusin', () => header.classList.remove('is-hidden'));

  /* Menú móvil ------------------------------------------------------------ */
  const toggle = $('.nav__toggle');
  const menu = $('[data-mobile-menu]');
  if (toggle && menu) {
    const mmNav = $('.mobile-menu__nav', menu);
    if (mmNav) Array.from(mmNav.children).forEach((el, i) => el.style.setProperty('--i', String(i)));
    const setMenu = (open) => {
      document.body.classList.toggle('menu-open', open);
      document.body.classList.toggle('is-locked', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
      menu.inert = !open;
      menu.setAttribute('aria-hidden', String(!open));
      if (open) header?.classList.remove('is-hidden');
    };
    setMenu(false);
    toggle.addEventListener('click', () => setMenu(!document.body.classList.contains('menu-open')));
    menu.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
    addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && document.body.classList.contains('menu-open')) { setMenu(false); toggle.focus(); }
    });
    matchMedia('(min-width: 1141px)').addEventListener?.('change', (e) => { if (e.matches) setMenu(false); });
    $$('[data-mm-group]', menu).forEach((g) => {
      const b = $('.mm-group__btn', g);
      const panel = $('.mm-group__panel', g);
      const set = (open) => { g.classList.toggle('is-open', open); b.setAttribute('aria-expanded', String(open)); panel.inert = !open; };
      set(g.classList.contains('is-open'));
      b.addEventListener('click', () => set(!g.classList.contains('is-open')));
    });
  }

  /* Submenú de escritorio (Planes): ratón, clic, teclado y Escape -------- */
  $$('[data-dd]').forEach((dd) => {
    const btn = $('.nav__item', dd);
    let byHover = false;
    let closeT = 0;
    const set = (open) => {
      clearTimeout(closeT);
      dd.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
      if (!open) byHover = false;
    };
    btn.addEventListener('click', () => {
      if (dd.classList.contains('is-open') && byHover) { byHover = false; return; }
      set(!dd.classList.contains('is-open'));
    });
    dd.addEventListener('pointerenter', (e) => {
      if (e.pointerType !== 'mouse' || dd.classList.contains('is-open')) { clearTimeout(closeT); return; }
      byHover = true;
      set(true);
    });
    dd.addEventListener('pointerleave', (e) => {
      if (e.pointerType !== 'mouse' || !byHover) return;
      closeT = setTimeout(() => set(false), 220);
    });
    document.addEventListener('click', (e) => { if (!dd.contains(e.target)) set(false); });
    dd.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && dd.classList.contains('is-open')) { set(false); btn.focus(); }
      if (e.key === 'ArrowDown' && e.target === btn) { e.preventDefault(); set(true); $('.nav__dd-panel a', dd)?.focus(); }
    });
    dd.addEventListener('focusout', (e) => { if (e.relatedTarget && !dd.contains(e.relatedTarget)) set(false); });
  });

  /* Palabras: cortar texto respetando etiquetas internas ----------------- */
  function splitWords(el, inner) {
    let i = 0;
    const walk = (node) => {
      Array.from(node.childNodes).forEach((n) => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach((part) => {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.append(document.createTextNode(' ')); return; }
            const w = document.createElement('span');
            w.className = 'w';
            w.style.setProperty('--i', String(i));
            i += 1;
            if (inner) { const s = document.createElement('span'); s.textContent = part; w.append(s); } else w.textContent = part;
            frag.append(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1 && n.tagName !== 'BR') walk(n);
      });
    };
    walk(el);
    return $$('.w', el);
  }

  /* Aparición al entrar en pantalla -------------------------------------- */
  $$('[data-split]').forEach((el) => splitWords(el, true));
  const revealIO = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      revealIO.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
  $$('[data-reveal], [data-split], .bars').forEach((el) => {
    if (reduce) { el.classList.add('is-in'); return; }
    revealIO.observe(el);
  });

  /* Párrafos que se iluminan palabra a palabra --------------------------- */
  const scrubs = $$('[data-scrub]').map((el) => ({ el, words: splitWords(el, false), lit: -1 }));

  /* Escenas fijadas, cartas apiladas, imágenes que crecen ---------------- */
  const scenes = $$('[data-scene]').map((el) => ({ el, name: el.dataset.scene, top: 0, h: 0, p: -1 }));
  const stacks = $$('[data-stack]').map((el) => ({ el, cards: $$('.stack__card', el) }));
  const zooms = $$('[data-zoom]');
  const tiltScene = { tx: 0, ty: 0 };

  function measure() {
    scenes.forEach((s) => {
      SETUP[s.name]?.(s);
      const r = s.el.getBoundingClientRect();
      s.top = r.top + scrollY;
      s.h = s.el.offsetHeight;
    });
  }

  const SETUP = {
    // Ajusta el panel 3D del CRM al tamaño de pantalla
    'crm-hero': (s) => {
      const dash = $('.dash', s.el);
      if (!dash) return;
      const dh = dash.offsetHeight || 640;
      const narrow = innerWidth <= 900 || reduce;
      const gutter = parseFloat(getComputedStyle($('.wrap', s.el) || s.el).paddingLeft) || 16;
      const fit = narrow
        ? (Math.min(innerWidth, 1300) - gutter * 2) / 1040
        : Math.min(1, (innerWidth * 0.9) / 1040, (innerHeight * 0.72) / dh);
      s.el.style.setProperty('--fit', fit.toFixed(4));
      s.el.style.setProperty('--dh', `${dh}px`);
      s.narrow = narrow;
      if (narrow) { s.el.style.setProperty('--a', '1'); s.el.style.setProperty('--c', '0'); s.el.style.setProperty('--cap', '0'); }
    },
  };

  // Galería horizontal: la altura de la sección es el recorrido horizontal
  SETUP.hscroll = (s) => {
    const track = $('.hs__track', s.el);
    s.narrow = innerWidth <= 900 || reduce;
    if (!track || s.narrow) { s.el.style.height = ''; return; }
    s.dist = Math.max(0, track.scrollWidth - innerWidth);
    s.el.style.height = `${Math.round(s.dist + innerHeight * 1.15)}px`;
  };

  // Túnel de profundidad: la cámara avanza y cada panel viene hacia ti
  SETUP.tunnel = (s) => {
    s.narrow = innerWidth <= 900 || reduce;
    s.panels = $$('.tun__panel', s.el);
    s.frames = $$('.tun__frame', s.el);
    s.rail = $$('.tun__rail li', s.el);
    s.world = $('.tun__world', s.el);
    s.gap = Number(s.el.dataset.gap || 1700);
    if (s.narrow) s.panels.forEach((el) => { el.style.removeProperty('--o'); el.style.visibility = ''; el.classList.add('is-active'); });
  };

  SETUP['app-steps'] = (s) => {
    s.narrow = innerWidth <= 900 || reduce;
    s.dots = $$('.ap-steps__rail i', s.el);
    s.items = $$('[data-step]', s.el).filter((el) => !el.closest('.ap-steps__rail'));
  };

  const HOOKS = {
    tunnel: (s, p) => {
      if (s.narrow || !s.world) return;
      const n = s.panels.length;
      const q = clamp(p * 1.06 - 0.03) * (n - 1);
      const k = Math.min(n - 2, Math.floor(q));
      const t = q - k;
      const f = t < 0.3 ? 0 : t > 0.7 ? 1 : ease((t - 0.3) / 0.4);
      const cam = (k + f) * s.gap;
      const near = Math.round(k + f);
      s.world.style.setProperty('--cam', cam.toFixed(1));
      s.panels.forEach((el, i) => {
        const z = cam - i * s.gap;
        const o = z <= 0 ? clamp(1 + z / (s.gap * 1.15)) : clamp(1 - z / 380);
        el.style.setProperty('--o', o.toFixed(3));
        el.style.visibility = o < 0.01 ? 'hidden' : '';
        el.classList.toggle('is-active', i === near);
      });
      s.frames.forEach((el) => {
        const z = cam - parseFloat(el.style.getPropertyValue('--k')) * s.gap;
        const o = z <= 0 ? clamp(1 + z / (s.gap * 2.2)) : clamp(1 - z / 520);
        el.style.setProperty('--o', (o * 0.7).toFixed(3));
      });
      s.rail.forEach((li, i) => li.classList.toggle('is-on', i === near));
    },
    hscroll: (s, p) => {
      if (s.narrow) return;
      const e = clamp((p - 0.06) / 0.88);
      s.el.style.setProperty('--hs', (e * s.dist).toFixed(1));
      s.el.style.setProperty('--p', e.toFixed(4));
    },
    'app-steps': (s, p) => {
      if (s.narrow) return;
      const n = Number(s.el.dataset.steps || 5);
      const step = Math.min(n - 1, Math.floor(p * n * 0.9999));
      s.el.style.setProperty('--p', p.toFixed(4));
      if (step === s.step) return;
      s.step = step;
      s.items.forEach((el) => el.classList.toggle('is-on', Number(el.dataset.step) === step));
      s.dots.forEach((d, k) => { d.classList.toggle('is-on', k === step); d.classList.toggle('is-done', k < step); });
    },
    'crm-hero': (s, p) => {
      if (s.narrow) return;
      const a = ease(clamp((p - 0.04) / 0.62));
      s.el.style.setProperty('--a', a.toFixed(4));
      s.el.style.setProperty('--c', clamp(p / 0.3).toFixed(4));
      s.el.style.setProperty('--cap', clamp((p - 0.72) / 0.16).toFixed(4));
      s.a = a;
    },
  };

  function frameScroll() {
    const y = scrollY;
    const vh = innerHeight;
    scenes.forEach((s) => {
      const p = clamp((y - s.top) / Math.max(1, s.h - vh));
      if (Math.abs(p - s.p) > 0.0005) { s.p = p; HOOKS[s.name]?.(s, p); }
    });
    stacks.forEach(({ cards }) => {
      if (innerWidth <= 900) return;
      for (let i = 0; i < cards.length - 1; i += 1) {
        const cur = cards[i].getBoundingClientRect();
        const next = cards[i + 1].getBoundingClientRect();
        const s = clamp(1 - (next.top - cur.top - 22) / Math.max(1, cur.height - 22));
        cards[i].style.setProperty('--s', s.toFixed(3));
      }
    });
    zooms.forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.bottom < -50 || r.top > vh + 50) return;
      const enter = clamp((vh - r.top) / (vh * 0.75));
      const exit = clamp((vh * 0.3 - r.bottom) / (vh * 0.3));
      el.style.setProperty('--zs', (0.82 + 0.18 * easeOut(enter)).toFixed(4));
      el.style.setProperty('--zo', (1 - 0.78 * exit).toFixed(3));
    });
    scrubs.forEach((s) => {
      const r = s.el.getBoundingClientRect();
      const p = clamp((vh * 0.9 - r.top) / (r.height + vh * 0.4));
      const lit = Math.round(p * s.words.length * 1.08);
      if (lit === s.lit) return;
      s.lit = lit;
      s.words.forEach((w, i) => w.classList.toggle('on', i < lit));
    });
    updateHeader(y);
  }

  /* Marquesinas: cinta infinita que acelera y cambia de sentido con el scroll */
  let scrollVel = 0;
  let prevY = scrollY;
  const marquees = $$('[data-marquee]').map((m) => {
    const track = $('.marquee__track', m);
    const dir = Number(m.dataset.marquee) || 1;
    const originals = Array.from(track.children);
    const w0 = track.scrollWidth;
    let guard = 0;
    while (track.scrollWidth < w0 + m.clientWidth + 200 && guard < 8) {
      originals.forEach((ch) => { const c = ch.cloneNode(true); c.setAttribute('aria-hidden', 'true'); track.append(c); });
      guard += 1;
    }
    return { m, track, dir, w0: Math.max(1, w0), x: 0, live: true };
  });
  if (marquees.length && 'IntersectionObserver' in window) {
    const mio = new IntersectionObserver((es) => es.forEach((e) => {
      const mq = marquees.find((q) => q.m === e.target);
      if (mq) mq.live = e.isIntersecting;
    }));
    marquees.forEach((q) => mio.observe(q.m));
  }
  let lastDir = 1;
  function frameMarquee(dt) {
    if (reduce) return;
    const y = scrollY;
    const v = (y - prevY) / Math.max(dt, 0.001);
    prevY = y;
    scrollVel += (v - scrollVel) * Math.min(1, dt * 6);
    if (scrollVel > 30) lastDir = 1; else if (scrollVel < -30) lastDir = -1;
    const boost = 1 + Math.min(7, Math.abs(scrollVel) / 260);
    marquees.forEach((q) => {
      if (!q.live) return;
      q.x -= 46 * boost * q.dir * lastDir * dt;
      if (q.x <= -q.w0) q.x += q.w0;
      if (q.x > 0) q.x -= q.w0;
      q.track.style.transform = `translate3d(${q.x.toFixed(2)}px,0,0)`;
    });
  }

  /* Inclinación del panel del héroe con el puntero ----------------------- */
  function frameHeroTilt() {
    if (!P || !fine || reduce) return;
    scenes.forEach((s) => {
      if (s.name !== 'crm-hero' || s.narrow || s.p >= 1 || s.p < 0) return;
      const k = 1 - (s.a || 0);
      const tx = (-P.pointer.y * 5 * k).toFixed(2);
      const ty = (P.pointer.x * 7 * k).toFixed(2);
      if (tx === tiltScene.tx && ty === tiltScene.ty) return;
      tiltScene.tx = tx; tiltScene.ty = ty;
      s.el.style.setProperty('--tx', `${tx}deg`);
      s.el.style.setProperty('--ty', `${ty}deg`);
    });
  }

  /* Elementos que siguen al puntero (exponen --px y --py de -1 a 1) */
  const pointerEls = $$('[data-pointer]').map((el) => ({ el, live: true, x: 9, y: 9 }));
  if (pointerEls.length && 'IntersectionObserver' in window) {
    const pio = new IntersectionObserver((es) => es.forEach((e) => {
      const q = pointerEls.find((o) => o.el === e.target);
      if (q) q.live = e.isIntersecting;
    }));
    pointerEls.forEach((q) => pio.observe(q.el));
  }
  function framePointer() {
    if (!P || !fine || reduce) return;
    const x = P.pointer.x.toFixed(3);
    const y = P.pointer.y.toFixed(3);
    pointerEls.forEach((q) => {
      if (!q.live || (q.x === x && q.y === y)) return;
      q.x = x; q.y = y;
      q.el.style.setProperty('--px', x);
      q.el.style.setProperty('--py', y);
    });
  }

  let lastFrameY = -1;
  let lastW = innerWidth;
  function frame(dt) {
    if (scrollY !== lastFrameY) { lastFrameY = scrollY; frameScroll(); }
    frameMarquee(dt || 0.016);
    frameHeroTilt();
    framePointer();
  }
  measure();
  frameScroll();
  if (P && P.addLoop) P.addLoop((dt) => frame(dt));
  else {
    let t0 = performance.now();
    const loop = (t) => { frame(Math.min(0.05, (t - t0) / 1000)); t0 = t; requestAnimationFrame(loop); };
    requestAnimationFrame(loop);
  }
  addEventListener('resize', () => {
    if (innerWidth === lastW && innerWidth <= 900) return; // la barra del móvil cambia el alto: no recalcular
    lastW = innerWidth;
    measure();
    lastFrameY = -1;
  });
  addEventListener('load', () => { measure(); lastFrameY = -1; });
  document.fonts?.ready.then(() => { measure(); lastFrameY = -1; });

  /* Inclinación 3D de tarjetas ------------------------------------------- */
  if (fine && !reduce) {
    $$('[data-tilt]').forEach((el) => {
      const max = Number(el.dataset.tilt) || 7;
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        el.classList.add('is-tilting');
        el.style.setProperty('--rx', `${((0.5 - y) * max).toFixed(2)}deg`);
        el.style.setProperty('--ry', `${((x - 0.5) * max).toFixed(2)}deg`);
        el.style.setProperty('--gx', `${(x * 100).toFixed(1)}%`);
        el.style.setProperty('--gy', `${(y * 100).toFixed(1)}%`);
      });
      el.addEventListener('pointerleave', () => {
        el.classList.remove('is-tilting');
        el.style.setProperty('--rx', '0deg');
        el.style.setProperty('--ry', '0deg');
      });
    });
  }

  /* Contadores ----------------------------------------------------------- */
  const fmt = (v, d) => new Intl.NumberFormat('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d }).format(v);
  const countIO = new IntersectionObserver((es) => {
    es.forEach((e) => {
      if (!e.isIntersecting) return;
      countIO.unobserve(e.target);
      const el = e.target;
      const to = parseFloat(el.dataset.count);
      const d = parseInt(el.dataset.decimals || '0', 10);
      const pre = el.dataset.prefix || '';
      const suf = el.dataset.suffix || '';
      if (reduce) { el.textContent = pre + fmt(to, d) + suf; return; }
      const t0 = performance.now();
      const tick = (t) => {
        const k = clamp((t - t0) / 1800);
        el.textContent = pre + fmt(to * (k === 1 ? 1 : 1 - Math.pow(2, -10 * k)), d) + suf;
        if (k < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }, { threshold: 0.6 });
  $$('[data-count]').forEach((el) => {
    if (!reduce && el.getBoundingClientRect().top > innerHeight) {
      el.textContent = (el.dataset.prefix || '') + fmt(0, parseInt(el.dataset.decimals || '0', 10)) + (el.dataset.suffix || '');
    }
    countIO.observe(el);
  });

  /* Pestañas ------------------------------------------------------------- */
  $$('[data-tabs]').forEach((w) => {
    const btns = $$('[role="tab"]', w);
    const ind = $('.tabs__ind', w);
    const panels = btns.map((b) => document.getElementById(b.getAttribute('aria-controls')));
    const place = (b, instant) => {
      if (!ind || !b) return;
      if (instant) ind.style.transition = 'none';
      ind.style.width = `${b.offsetWidth}px`;
      ind.style.transform = `translateX(${b.offsetLeft - 5}px)`;
      if (instant) requestAnimationFrame(() => { ind.style.transition = ''; });
    };
    const current = () => btns.find((b) => b.getAttribute('aria-selected') === 'true');
    const select = (i, focus) => {
      btns.forEach((b, k) => {
        const on = k === i;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        if (panels[k]) panels[k].hidden = !on;
      });
      place(btns[i]);
      if (focus) btns[i].focus();
    };
    btns.forEach((b, i) => {
      b.addEventListener('click', () => select(i));
      b.addEventListener('keydown', (e) => {
        const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
        if (!d) return;
        e.preventDefault();
        select((i + d + btns.length) % btns.length, true);
      });
    });
    select(Math.max(0, btns.indexOf(current())));
    place(current(), true);
    addEventListener('resize', () => place(current(), true));
    document.fonts?.ready.then(() => place(current(), true));
  });

  /* Preguntas frecuentes -------------------------------------------------- */
  let uid = 0;
  $$('.faq').forEach((group) => {
    const items = $$('.faq__item', group);
    const setItem = (item, open) => {
      item.classList.toggle('is-open', open);
      $('.faq__q', item).setAttribute('aria-expanded', String(open));
      $('.faq__a', item).inert = !open;
    };
    items.forEach((item) => {
      const q = $('.faq__q', item);
      const a = $('.faq__a', item);
      uid += 1;
      q.id = `faq-q-${uid}`;
      a.id = `faq-a-${uid}`;
      q.setAttribute('aria-controls', a.id);
      a.setAttribute('role', 'region');
      a.setAttribute('aria-labelledby', q.id);
      if (!$('.i', q)) q.insertAdjacentHTML('beforeend', '<i class="i i-plus" aria-hidden="true"></i>');
      setItem(item, item.classList.contains('is-open'));
      q.addEventListener('click', () => {
        const open = !item.classList.contains('is-open');
        items.forEach((it) => { if (it !== item) setItem(it, false); });
        setItem(item, open);
      });
    });
  });

  /* Calculadora de rentabilidad (en la moneda del país elegido) ---------- */
  const M = window.BookmyMoney;
  const money = (v, code) => (M ? M.format(v, code) : new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(v));
  $$('[data-roi]').forEach((form) => {
    const inputs = $$('input[type="range"]', form);
    const select = $('[data-money-select]', form);
    const ticket = $('input[data-money]', form);
    let code = 'es';
    const out = (name, txt) => $$(`[data-res="${name}"]`, form).forEach((el) => { el.textContent = txt; });
    const calc = () => {
      const v = {};
      inputs.forEach((i) => {
        v[i.name] = Number(i.value);
        i.style.setProperty('--fill', `${((i.value - i.min) / (i.max - i.min)) * 100}%`);
        const o = $(`[data-out="${i.name}"]`, form);
        if (o) o.textContent = i.hasAttribute('data-money') ? money(i.value, code) : `${i.value}${i.dataset.unit || ''}`;
      });
      const lost = v.citas * 4.33 * v.ticket * (v.ausencias / 100);
      const back = lost * (v.recupera / 100);
      out('perdida', money(lost, code));
      out('recupera', money(back, code));
      out('anual', money(back * 12, code));
      // La altura de las columnas se compara con un negocio tipo de cada país
      const ref = M ? (8000 * M.get(code).range[3]) / 35 : 8000;
      const lv = 0.42 + 0.58 * Math.sqrt(clamp(lost / ref));
      form.style.setProperty('--lostv', lv.toFixed(3));
      form.style.setProperty('--backv', Math.max(0.05, lv * (v.recupera / 100)).toFixed(3));
    };
    // País y moneda: cambia el rango del precio medio y el formato de los importes
    const setCountry = (c, keepTicket) => {
      if (!M) return;
      code = M.get(c).code;
      const cfg = M.get(code);
      if (ticket) {
        const [min, max, step, def] = cfg.range;
        Object.assign(ticket, { min, max, step });
        ticket.value = keepTicket ? clamp(Number(ticket.value), min, max) : def;
      }
      const o = $('[data-out="moneda"]', form);
      if (o) o.textContent = cfg.cur;
      calc();
    };
    if (select && M) {
      select.innerHTML = M.list.map((c) => `<option value="${c.code}">${c.name}${c.code === 'eu' || c.code === 'usd' ? '' : ` · ${c.curName}`}</option>`).join('');
      select.value = M.guess();
      select.addEventListener('change', () => setCountry(select.value, false));
      setCountry(select.value, false);
    }
    inputs.forEach((i) => i.addEventListener('input', calc));
    calc();
  });

  /* Demos de chat que se reproducen al entrar en pantalla ---------------- */
  $$('[data-chat-demo]').forEach((demo) => {
    const items = $$('.bubble', demo);
    const typing = $('.typing', demo);
    const annots = demo.dataset.annots ? $$(`#${demo.dataset.annots} li`) : [];
    let timers = [];
    const reset = () => {
      timers.forEach(clearTimeout);
      timers = [];
      items.forEach((b) => b.classList.remove('is-shown'));
      typing?.classList.remove('is-on');
      annots.forEach((a) => a.classList.remove('is-on'));
    };
    const play = () => {
      reset();
      let t = 350;
      items.forEach((b) => {
        const bot = b.classList.contains('bubble--out');
        if (bot && typing) {
          timers.push(setTimeout(() => { b.before(typing); typing.classList.add('is-on'); }, t));
          t += 950;
        }
        timers.push(setTimeout(() => {
          typing?.classList.remove('is-on');
          b.classList.add('is-shown');
          if (b.dataset.annot !== undefined) annots.forEach((a, i) => a.classList.toggle('is-on', String(i) === b.dataset.annot));
        }, t));
        t += bot ? 1500 : 1000;
      });
    };
    if (reduce) {
      items.forEach((b) => b.classList.add('is-shown'));
      annots.forEach((a) => a.classList.add('is-on'));
    } else {
      const io = new IntersectionObserver((es) => {
        if (es.some((e) => e.isIntersecting)) { io.disconnect(); play(); }
      }, { threshold: 0.35 });
      io.observe(demo);
    }
    $('[data-chat-replay]', demo)?.addEventListener('click', () => { if (!reduce) play(); });
  });

  /* Testimonios ---------------------------------------------------------- */
  $$('[data-carousel]').forEach((c) => {
    const slides = $$('.voice', c);
    const avs = $$('.voices__av', c);
    const cur = $('[data-current]', c);
    let i = 0;
    const go = (n) => {
      i = (n + slides.length) % slides.length;
      slides.forEach((s, k) => { s.classList.toggle('is-active', k === i); s.toggleAttribute('inert', k !== i); });
      avs.forEach((a, k) => a.classList.toggle('is-active', k === i));
      if (cur) cur.textContent = String(i + 1);
    };
    $('[data-prev]', c)?.addEventListener('click', () => go(i - 1));
    $('[data-next]', c)?.addEventListener('click', () => go(i + 1));
    c.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') go(i - 1);
      if (e.key === 'ArrowRight') go(i + 1);
    });
    let sx = 0;
    c.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
    c.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 50) go(i + (dx < 0 ? 1 : -1));
    });
    c.classList.add('is-ready');
    go(0);
  });

  /* Conmutador de modo claro / oscuro (demostración de la app) ---------- */
  $$('[data-theme-demo]').forEach((sec) => {
    const btns = $$('[data-mode-btn]', sec);
    const set = (mode) => {
      sec.dataset.mode = mode;
      btns.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.modeBtn === mode)));
    };
    btns.forEach((b) => b.addEventListener('click', () => set(b.dataset.modeBtn)));
  });

  /* Newsletter ----------------------------------------------------------- */
  $$('[data-newsletter]').forEach((f) => {
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = f.elements.email.value.trim();
      const msg = $('.news__msg', f);
      const endpoint = f.dataset.endpoint;
      if (endpoint) {
        try {
          const r = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, origen: 'newsletter' }) });
          if (!r.ok) throw new Error(String(r.status));
          msg.textContent = '¡Listo! Te hemos apuntado a la newsletter.';
          f.reset();
        } catch {
          msg.textContent = 'No se ha podido enviar. Inténtalo de nuevo en un momento.';
        }
        return;
      }
      const body = `Hola, quiero recibir la newsletter de Bookmy en este correo: ${email}`;
      location.href = `mailto:contacto@bookmy.es?subject=${encodeURIComponent('Alta en la newsletter')}&body=${encodeURIComponent(body)}`;
      msg.textContent = 'Abrimos tu correo para confirmar el alta.';
    });
  });

  /* Índice de las páginas legales ---------------------------------------- */
  const toc = $('[data-toc]');
  if (toc) {
    const links = $$('a[href^="#"]', toc);
    const byId = new Map(links.map((a) => [a.getAttribute('href').slice(1), a]));
    const io = new IntersectionObserver((es) => {
      es.forEach((e) => {
        if (!e.isIntersecting) return;
        links.forEach((a) => a.classList.remove('is-active'));
        byId.get(e.target.id)?.classList.add('is-active');
      });
    }, { rootMargin: '-18% 0px -72% 0px' });
    byId.forEach((_, id) => { const s = document.getElementById(id); if (s) io.observe(s); });
  }

  /* Volver desde la caché del navegador: recalcular ---------------------- */
  addEventListener('pageshow', (e) => { if (e.persisted) { measure(); lastFrameY = -1; } });
})();
