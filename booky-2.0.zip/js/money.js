/* ==========================================================================
   Bookmy · money.js — Países, monedas y formato de importes
   Lo usan la calculadora de la web (site.js), el asistente (assistant.js)
   y el formulario de alta (signup.js).
   API: window.BookmyMoney = {
     list,                 // países en el orden en que se muestran
     get(code),            // país por código ('es', 'mx'…)
     match(texto),         // reconoce un país o una moneda en lo que escribe el usuario
     guess(),              // país probable por la zona horaria y el idioma del navegador
     format(valor, code),  // importe con la moneda y el formato del país
     parse(texto),         // lee un importe escrito a mano: «70.000», «1,5 mil», «35 €»
   }
   Los importes de ejemplo (chips y rangos) son orientativos: cada negocio
   ajusta el suyo.
   ========================================================================== */
(() => {
  'use strict';

  // código, nombre, moneda, formato, prefijo telefónico,
  // calculadora [mín, máx, paso, valor inicial], chips [bajo, medio, alto], otras formas de escribirlo
  const RAW = [
    ['es', 'España', 'EUR', 'es-ES', '+34', [10, 200, 5, 35], [20, 35, 60], ['espana', 'spain', 'madrid', 'barcelona', 'malaga', 'sevilla', 'valencia', 'marbella', 'benalmadena', 'fuengirola', 'torremolinos', 'bilbao']],
    ['mx', 'México', 'MXN', 'es-MX', '+52', [100, 4000, 50, 500], [300, 500, 900], ['mexico', 'cdmx', 'guadalajara', 'monterrey', 'puebla', 'cancun']],
    ['co', 'Colombia', 'COP', 'es-CO', '+57', [10000, 600000, 5000, 70000], [40000, 70000, 150000], ['colombia', 'bogota', 'medellin', 'cali', 'barranquilla', 'cartagena']],
    ['ar', 'Argentina', 'ARS', 'es-AR', '+54', [2000, 300000, 1000, 30000], [15000, 30000, 60000], ['argentina', 'buenos aires', 'rosario', 'mendoza']],
    ['cl', 'Chile', 'CLP', 'es-CL', '+56', [5000, 200000, 1000, 25000], [15000, 25000, 45000], ['chile', 'santiago de chile', 'valparaiso', 'vina del mar']],
    ['pe', 'Perú', 'PEN', 'es-PE', '+51', [20, 600, 5, 90], [50, 90, 180], ['peru', 'lima', 'arequipa', 'cusco']],
    ['ec', 'Ecuador', 'USD', 'es-EC', '+593', [5, 250, 5, 25], [15, 25, 50], ['ecuador', 'quito', 'guayaquil', 'cuenca']],
    ['us', 'Estados Unidos', 'USD', 'es-US', '+1', [10, 400, 5, 70], [40, 70, 120], ['estados unidos', 'eeuu', 'ee uu', 'usa', 'miami', 'nueva york', 'new york', 'texas', 'florida']],
    ['ve', 'Venezuela', 'USD', 'es-VE', '+58', [5, 200, 5, 20], [10, 20, 40], ['venezuela', 'caracas', 'maracaibo', 'valencia venezuela']],
    ['do', 'República Dominicana', 'DOP', 'es-DO', '+1', [300, 15000, 100, 2000], [1000, 2000, 4000], ['republica dominicana', 'dominicana', 'santo domingo', 'punta cana']],
    ['gt', 'Guatemala', 'GTQ', 'es-GT', '+502', [50, 1500, 10, 200], [100, 200, 400], ['guatemala']],
    ['cr', 'Costa Rica', 'CRC', 'es-CR', '+506', [5000, 150000, 1000, 20000], [10000, 20000, 40000], ['costa rica']],
    ['pa', 'Panamá', 'USD', 'es-PA', '+507', [5, 300, 5, 35], [20, 35, 60], ['panama']],
    ['uy', 'Uruguay', 'UYU', 'es-UY', '+598', [300, 10000, 100, 1500], [800, 1500, 3000], ['uruguay', 'montevideo', 'punta del este']],
    ['py', 'Paraguay', 'PYG', 'es-PY', '+595', [30000, 1500000, 10000, 200000], [100000, 200000, 400000], ['paraguay', 'asuncion']],
    ['bo', 'Bolivia', 'BOB', 'es-BO', '+591', [30, 1000, 10, 150], [70, 150, 300], ['bolivia', 'la paz', 'cochabamba']],
    ['hn', 'Honduras', 'HNL', 'es-HN', '+504', [100, 4000, 50, 600], [300, 600, 1200], ['honduras', 'tegucigalpa', 'san pedro sula']],
    ['sv', 'El Salvador', 'USD', 'es-SV', '+503', [5, 250, 5, 25], [15, 25, 50], ['el salvador', 'san salvador']],
    ['ni', 'Nicaragua', 'NIO', 'es-NI', '+505', [100, 5000, 50, 800], [400, 800, 1600], ['nicaragua', 'managua']],
    ['pr', 'Puerto Rico', 'USD', 'es-PR', '+1', [10, 300, 5, 50], [30, 50, 90], ['puerto rico', 'san juan']],
    ['pt', 'Portugal', 'EUR', 'pt-PT', '+351', [10, 200, 5, 30], [20, 30, 50], ['portugal', 'lisboa', 'oporto', 'porto']],
    ['eu', 'Otro país (euros)', 'EUR', 'es-ES', '', [10, 200, 5, 35], [20, 35, 60], ['euro', 'euros', 'eur']],
    ['usd', 'Otro país (dólares)', 'USD', 'es-US', '', [5, 300, 5, 40], [20, 40, 70], ['dolar', 'dolares', 'usd']],
  ];
  const CUR_NAME = {
    EUR: 'euros', USD: 'dólares', MXN: 'pesos mexicanos', COP: 'pesos colombianos', ARS: 'pesos argentinos', CLP: 'pesos chilenos',
    PEN: 'soles', DOP: 'pesos dominicanos', GTQ: 'quetzales', CRC: 'colones', UYU: 'pesos uruguayos', PYG: 'guaraníes',
    BOB: 'bolivianos', HNL: 'lempiras', NIO: 'córdobas',
  };
  const list = RAW.map(([code, name, cur, loc, dial, range, chips, alias]) => ({
    code, name, cur, loc, dial, range, chips, alias, curName: CUR_NAME[cur] || cur,
  }));
  const byCode = Object.fromEntries(list.map((c) => [c.code, c]));
  const get = (code) => byCode[code] || byCode.es;

  const plain = (s) => ` ${String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9$€\s]/g, ' ').replace(/\s+/g, ' ').trim()} `;

  // Reconoce el país (o la moneda) en un texto libre: «estoy en Bogotá», «trabajo con pesos mexicanos»…
  function match(text) {
    const t = plain(text);
    let best = null;
    let bestLen = 0;
    list.forEach((c) => {
      [plain(c.name).trim(), ...c.alias].forEach((a) => {
        if (a && t.includes(` ${a} `) && a.length > bestLen) { best = c.code; bestLen = a.length; }
      });
    });
    if (best) return best;
    if (/ pesos? mexicanos? | mxn /.test(t)) return 'mx';
    if (/ pesos? colombianos? | cop /.test(t)) return 'co';
    if (/ pesos? argentinos? | ars /.test(t)) return 'ar';
    if (/ pesos? chilenos? | clp /.test(t)) return 'cl';
    if (/ soles? /.test(t)) return 'pe';
    if (/ € /.test(t)) return 'eu';
    if (/ \$ /.test(t)) return 'usd';
    return null;
  }

  // País probable: primero la zona horaria, después el idioma del navegador
  const TZ = {
    'Europe/Madrid': 'es', 'Atlantic/Canary': 'es', 'Africa/Ceuta': 'es', 'America/Mexico_City': 'mx', 'America/Cancun': 'mx',
    'America/Monterrey': 'mx', 'America/Tijuana': 'mx', 'America/Merida': 'mx', 'America/Chihuahua': 'mx', 'America/Hermosillo': 'mx',
    'America/Bogota': 'co', 'America/Santiago': 'cl', 'America/Lima': 'pe', 'America/Guayaquil': 'ec', 'America/Caracas': 've',
    'America/Santo_Domingo': 'do', 'America/Guatemala': 'gt', 'America/Costa_Rica': 'cr', 'America/Panama': 'pa',
    'America/Montevideo': 'uy', 'America/Asuncion': 'py', 'America/La_Paz': 'bo', 'America/Tegucigalpa': 'hn',
    'America/El_Salvador': 'sv', 'America/Managua': 'ni', 'America/Puerto_Rico': 'pr', 'Europe/Lisbon': 'pt',
  };
  function guess() {
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      if (TZ[tz]) return TZ[tz];
      if (tz.startsWith('America/Argentina')) return 'ar';
      if (/^America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Detroit|Anchorage|Indiana)/.test(tz)) return 'us';
    } catch (e) { /* sin Intl */ }
    const lang = (navigator.language || '').toLowerCase();
    const region = lang.split('-')[1];
    if (region && byCode[region]) return region;
    if (lang.startsWith('pt')) return 'pt';
    return 'es';
  }

  const fmtCache = {};
  function format(v, code) {
    const c = get(code);
    const key = c.loc + c.cur;
    if (!fmtCache[key]) {
      try { fmtCache[key] = new Intl.NumberFormat(c.loc, { style: 'currency', currency: c.cur, maximumFractionDigits: 0 }); }
      catch (e) { fmtCache[key] = new Intl.NumberFormat('es-ES', { style: 'currency', currency: c.cur, maximumFractionDigits: 0 }); }
    }
    return fmtCache[key].format(Math.round(v));
  }

  // Importe escrito a mano: admite puntos o comas de miles, «mil», «k» y «millones»
  function parse(text) {
    const s = String(text).toLowerCase().replace(/ /g, ' ');
    const m = s.match(/(\d[\d.,\s]*)\s*(k\b|mil\b|millon(?:es)?\b)?/);
    if (!m) return null;
    let num = m[1].trim().replace(/\s+/g, '');
    if (/^\d{1,3}([.,]\d{3})+$/.test(num)) num = num.replace(/[.,]/g, '');
    else if (/^\d+[.,]\d{1,2}$/.test(num)) num = num.replace(',', '.');
    else num = num.replace(/[.,]/g, '');
    let v = parseFloat(num);
    if (!Number.isFinite(v) || v <= 0) return null;
    if (m[2] === 'k' || m[2] === 'mil') v *= 1000;
    else if (m[2] && m[2].startsWith('millon')) v *= 1e6;
    return v;
  }

  window.BookmyMoney = { list, get, match, guess, format, parse };
})();
