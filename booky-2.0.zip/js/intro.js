/* ==========================================================================
   Bookmy · intro.js — Página de entrada
   Una escultura de partículas con el logo de Bookmy flota en el centro.
   Al pasar por "La app" se convierte en un teléfono verde (el verde del
   logo); por "El CRM", en un gráfico de barras 3D verde lima. Al elegir, estalla y el campo de estrellas salta
   a la velocidad de la luz hacia la página elegida.
   Se elige con un toque, con el teclado (A / C) o con Tab + Intro.
   API: window.BookmyIntro.choose('app' | 'crm')
   ========================================================================== */
(() => {
  'use strict';

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const intro = $('[data-intro]');
  if (!intro) return;

  const P = window.BookmyParticles;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const gates = $$('.gate', intro);
  const status = $('.portal__status', intro);
  const floaters = $('.portal__floaters', intro);
  $$('[data-year]').forEach((el) => { el.textContent = String(new Date().getFullYear()); });

  // Si viene de otra página de la web, entra sin hacerle esperar
  const fromSite = (() => {
    try { return Boolean(document.referrer) && new URL(document.referrer).origin === location.origin; } catch { return false; }
  })();
  if (fromSite) intro.classList.add('is-fast');

  /* Escena: estrellas + escultura ---------------------------------------- */
  let stars = null;
  let sculpt = null;
  try {
    if (P) {
      stars = P.field($('.portal__stars', intro), { cy: 0.46 });
      sculpt = P.sculpture($('.portal__sculpture', intro), {
        shapes: ['logo', 'phone', 'bars'], extent: 1.2, swing: 0.38, size: innerWidth < 700 ? 1.7 : 1.45, count: innerWidth < 700 ? 950 : 1500,
      });
    }
  } catch (err) { /* sin partículas la página sigue funcionando */ }

  // Los chips del fondo siguen al puntero según su profundidad
  if (P && fine && !reduce && floaters) {
    P.addLoop(() => {
      floaters.style.setProperty('--px', (P.pointer.x * -30).toFixed(2));
      floaters.style.setProperty('--py', (P.pointer.y * -20).toFixed(2));
    }, floaters);
  }

  requestAnimationFrame(() => requestAnimationFrame(() => { intro.dataset.state = 'ready'; }));

  /* Pasar por encima: la escultura cambia de forma ----------------------- */
  const SHAPE = { app: 'phone', crm: 'bars' };
  let hoverTimer = 0;
  let busy = false;
  function setHover(kind) {
    if (busy) return;
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => {
      if (kind) intro.dataset.hover = kind; else delete intro.dataset.hover;
      sculpt?.morph(SHAPE[kind] || 'logo');
      tint(kind);
    }, kind ? 40 : 240);
  }

  // Cada portal lleva el color de su producto (clases .t-app y .t-crm)
  function tint(kind) {
    const gate = kind ? gates.find((g) => g.dataset.choice === kind) : null;
    sculpt?.tint(gate);
    stars?.tint(gate);
  }

  gates.forEach((g) => {
    const kind = g.dataset.choice;
    g.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch') setHover(kind); });
    g.addEventListener('pointerleave', () => setHover(null));
    g.addEventListener('focus', () => setHover(kind));
    g.addEventListener('blur', () => setHover(null));

    // Inclinación 3D y brillo que sigue al cursor
    if (fine && !reduce) {
      g.addEventListener('pointermove', (e) => {
        const r = g.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        g.style.setProperty('--rx', `${((0.5 - y) * 16).toFixed(2)}deg`);
        g.style.setProperty('--ry', `${((x - 0.5) * 10).toFixed(2)}deg`);
        g.style.setProperty('--mx', `${(x * 100).toFixed(1)}%`);
        g.style.setProperty('--my', `${(y * 100).toFixed(1)}%`);
      });
      g.addEventListener('pointerleave', () => {
        g.style.setProperty('--rx', '0deg');
        g.style.setProperty('--ry', '0deg');
      });
    }

    g.addEventListener('click', (e) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      e.preventDefault();
      choose(kind, g.getAttribute('href'));
    });
  });

  /* Elegir: estallido + salto a la velocidad de la luz -------------------- */
  const LABEL = { app: 'Abriendo la app…', crm: 'Abriendo el CRM…' };
  const ROUTES = { app: 'app.html', crm: 'crm.html' };
  function choose(kind, href = ROUTES[kind]) {
    if (busy || !href) return;
    busy = true;
    clearTimeout(hoverTimer);
    status.textContent = LABEL[kind] || 'Abriendo…';
    gates.forEach((g) => g.classList.toggle('is-picked', g.dataset.choice === kind));
    if (reduce || !sculpt) { location.href = href; return; }
    intro.dataset.hover = kind;
    sculpt.morph(SHAPE[kind] || 'logo');
    tint(kind);
    setTimeout(() => {
      sculpt.burst();
      stars?.warp(2.6);
      intro.dataset.state = 'leaving';
    }, 280);
    setTimeout(() => { location.href = href; }, 1250);
  }

  addEventListener('keydown', (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
    if (e.target.closest('input, textarea, select, dialog, [contenteditable]')) return;
    const k = e.key.toLowerCase();
    if (k === 'a') choose('app');
    if (k === 'c') choose('crm');
  });

  /* Volver atrás desde otra página (caché del navegador) ----------------- */
  addEventListener('pageshow', (e) => {
    if (!e.persisted) return;
    busy = false;
    status.textContent = '';
    delete intro.dataset.hover;
    intro.classList.add('is-fast');
    intro.dataset.state = 'ready';
    gates.forEach((g) => g.classList.remove('is-picked'));
    stars?.warp(0);
    sculpt?.reset();
    sculpt?.morph('logo');
    tint(null);
  });

  window.BookmyIntro = { choose };
})();
