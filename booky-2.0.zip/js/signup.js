/* ==========================================================================
   Bookmy · signup.js — Formulario de alta (crear-cuenta.html)
   - Elige plan con ?plan=basic|pro (también acepta ?plan=free = Basic).
   - Valida en el navegador y envía a api/registro.php, que manda el email
     a appbookmy20025@gmail.com con copia a info@qoretechnology.com.
   - Si el servidor no responde, ofrece enviarlo por email o WhatsApp
     con los datos ya escritos, para no perder la solicitud.
   ========================================================================== */
(() => {
  'use strict';

  const form = document.querySelector('[data-signup]');
  if (!form) return;
  const $ = (s, c = form) => c.querySelector(s);
  const M = window.BookmyMoney;
  const done = document.querySelector('.su-done');
  const msg = $('.su-msg');
  const submit = $('.su-submit');
  const label = $('[data-submit-label]');
  const PLANS = { basic: 'Plan Basic', pro: 'Plan Pro' };
  const WHATSAPP = '34651026700';

  /* Plan desde la URL ----------------------------------------------------- */
  const params = new URLSearchParams(location.search);
  const want = (params.get('plan') || '').toLowerCase();
  const planKey = want === 'basic' || want === 'free' || want === 'basico' ? 'basic' : 'pro';
  const radio = $(`input[name="plan"][value="${planKey}"]`);
  if (radio) radio.checked = true;
  const plan = () => ($('input[name="plan"]:checked') || {}).value || 'pro';
  const syncPlan = () => { if (label) label.textContent = `Enviar solicitud · ${PLANS[plan()]}`; };
  form.addEventListener('change', (e) => { if (e.target.name === 'plan') syncPlan(); });
  syncPlan();

  /* País: se propone el probable y el teléfono muestra su prefijo --------- */
  const pais = $('[data-country-select]');
  const tel = $('#su-telefono');
  if (pais && M) {
    const opts = M.list.filter((c) => c.code !== 'eu' && c.code !== 'usd');
    pais.innerHTML = `<option value="">Elige tu país</option>${opts.map((c) => `<option value="${c.name}" data-code="${c.code}">${c.name}</option>`).join('')}<option value="Otro país">Otro país</option>`;
    const g = M.get(M.guess());
    if (opts.includes(g)) pais.value = g.name;
    const dial = () => {
      const code = pais.selectedOptions[0]?.dataset.code;
      const d = code ? M.get(code).dial : '';
      if (tel) tel.placeholder = d ? `${d} …` : 'Tu teléfono';
    };
    pais.addEventListener('change', dial);
    dial();
  }

  /* Validación ------------------------------------------------------------ */
  const RULES = {
    nombre: (v) => (v.trim().length >= 2 ? '' : 'Escribe tu nombre completo.'),
    email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Escribe un correo válido, por ejemplo nombre@negocio.com.'),
    telefono: (v) => (v.replace(/\D/g, '').length >= 7 ? '' : 'Escribe un teléfono con al menos 7 cifras.'),
    pais: (v) => (v ? '' : 'Elige tu país.'),
    tipo: (v) => (v ? '' : 'Elige el tipo de empresa.'),
  };
  const errEl = (name) => document.getElementById(name === 'consentimiento' ? 'su-consent-err' : `su-${name}-err`);
  function setErr(name, text) {
    const field = form.elements[name];
    const el = errEl(name);
    if (el) el.textContent = text;
    if (field && field.setAttribute) field.setAttribute('aria-invalid', text ? 'true' : 'false');
    return !text;
  }
  function check(name) {
    if (name === 'consentimiento') return setErr(name, form.elements.consentimiento.checked ? '' : 'Necesitamos tu permiso para tramitar el alta.');
    const rule = RULES[name];
    return rule ? setErr(name, rule(form.elements[name].value)) : true;
  }
  ['nombre', 'email', 'telefono', 'pais', 'tipo'].forEach((n) => {
    const f = form.elements[n];
    f.addEventListener('blur', () => { if (f.value) check(n); });
    f.addEventListener('input', () => { if (f.getAttribute('aria-invalid') === 'true') check(n); });
    f.addEventListener('change', () => { if (f.getAttribute('aria-invalid') === 'true') check(n); });
  });
  form.elements.consentimiento.addEventListener('change', () => check('consentimiento'));

  const data = () => ({
    plan: plan(),
    planNombre: PLANS[plan()],
    nombre: form.elements.nombre.value.trim(),
    email: form.elements.email.value.trim(),
    telefono: form.elements.telefono.value.trim(),
    pais: form.elements.pais.value,
    tipo: form.elements.tipo.value,
    negocio: form.elements.negocio.value.trim(),
    consentimiento: form.elements.consentimiento.checked,
    web: form.elements.web.value,
    pagina: location.pathname.split('/').pop() || 'crear-cuenta.html',
  });

  const summary = (d) => `Solicitud de alta en Bookmy · ${d.planNombre} (7 días gratis)\n\n${[
    `Nombre: ${d.nombre}`,
    `Correo: ${d.email}`,
    `Teléfono: ${d.telefono}`,
    `País: ${d.pais}`,
    `Tipo de empresa: ${d.tipo}`,
    d.negocio && `Negocio: ${d.negocio}`,
  ].filter(Boolean).join('\n')}`;

  function showMsg(html, kind = 'error') {
    msg.innerHTML = html;
    msg.dataset.kind = kind;
    msg.hidden = false;
  }

  function showDone(d) {
    form.hidden = true;
    if (!done) return;
    done.querySelector('[data-done-email]').textContent = d.email;
    done.querySelector('[data-done-plan]').textContent = d.planNombre;
    done.hidden = false;
    done.focus({ preventScroll: true });
    done.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
  }

  // Sin servidor: el mismo contenido por email o WhatsApp
  function fallback(d) {
    const to = form.dataset.fallbackTo;
    const cc = form.dataset.fallbackCc;
    const text = summary(d);
    const subject = `Solicitud de alta · ${d.planNombre} · ${d.nombre}`;
    const mail = `mailto:${to}?${cc ? `cc=${encodeURIComponent(cc)}&` : ''}subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
    const wa = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`;
    showMsg(`<b>No hemos podido enviar tu solicitud.</b> Envíanosla con un clic, ya va escrita:
      <span class="su-msg__actions"><a class="btn btn--primary btn--sm" href="${mail}"><i class="i i-mail" aria-hidden="true"></i>Enviar por email</a><a class="btn btn--ghost btn--sm" href="${wa}" target="_blank" rel="noopener"><i class="i i-message-circle" aria-hidden="true"></i>Enviar por WhatsApp</a></span>`);
  }

  const SERVER_ERR = {
    nombre: ['nombre', 'Revisa tu nombre.'],
    email: ['email', 'Revisa tu correo.'],
    telefono: ['telefono', 'Revisa tu teléfono.'],
    pais: ['pais', 'Elige tu país.'],
    tipo: ['tipo', 'Elige el tipo de empresa.'],
    consentimiento: ['consentimiento', 'Necesitamos tu permiso para tramitar el alta.'],
  };

  let sending = false;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (sending) return;
    msg.hidden = true;
    const names = ['nombre', 'email', 'telefono', 'pais', 'tipo', 'consentimiento'];
    const results = names.map((n) => check(n));
    const firstBad = names[results.indexOf(false)];
    if (firstBad) {
      const f = form.elements[firstBad];
      (f.focus ? f : form.elements.nombre).focus();
      return;
    }
    const d = data();
    sending = true;
    submit.disabled = true;
    submit.classList.add('is-loading');
    if (label) label.textContent = 'Enviando…';
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 15000);
      const r = await fetch(form.dataset.endpoint || form.action, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(d),
        signal: ctl.signal,
      });
      clearTimeout(timer);
      const res = await r.json().catch(() => ({}));
      if (r.ok && res.ok) { showDone(d); return; }
      if (r.status === 422 && SERVER_ERR[res.error]) {
        const [name, text] = SERVER_ERR[res.error];
        setErr(name, text);
        form.elements[name]?.focus?.();
      } else if (r.status === 429) {
        showMsg('Has enviado varias solicitudes seguidas. Espera unos minutos y vuelve a intentarlo, o escríbenos por WhatsApp.');
      } else {
        fallback(d);
      }
    } catch (err) {
      fallback(d);
    } finally {
      sending = false;
      submit.disabled = false;
      submit.classList.remove('is-loading');
      syncPlan();
    }
  });
})();
