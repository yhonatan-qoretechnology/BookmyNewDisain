<?php
/**
 * Bookmy · Formulario de alta (crear-cuenta.html → api/registro.php)
 *
 * Envía cada solicitud por email a appbookmy20025@gmail.com con copia a
 * info@qoretechnology.com. PHP 8.1+ con mail() habilitado (lo normal en cPanel).
 *
 * - Acepta JSON (lo que envía js/signup.js) o un formulario normal (sin JavaScript).
 * - Valida los datos, frena a los bots con un campo trampa y limita los envíos por IP.
 * - Nunca recoge contraseñas ni datos de pago.
 *
 * Para cambiar los destinatarios sin tocar este archivo, crea api/config.php
 * (copia config.example.php) y rellena 'registro_to', 'registro_cc' y 'mail_from'.
 */
declare(strict_types=1);

$cfg = is_file(__DIR__ . '/config.php') ? (array) require __DIR__ . '/config.php' : [];

define('TO', (string) ($cfg['registro_to'] ?? 'appbookmy20025@gmail.com'));
define('CC', (string) ($cfg['registro_cc'] ?? 'info@qoretechnology.com'));
define('FROM', (string) ($cfg['mail_from'] ?? 'no-reply@bookmy.es')); // un buzón de tu dominio, para no acabar en spam
const ALLOWED_ORIGINS = ['https://bookmy.es', 'https://www.bookmy.es'];
const RATE_LIMIT = 5;      // solicitudes por IP…
const RATE_WINDOW = 3600;  // …cada hora
const PLANES = ['basic' => 'Plan Basic', 'pro' => 'Plan Pro'];
const TIPOS = ['Salud', 'Estética', 'Construcción', 'Tecnología', 'Servicios', 'Otros'];

$isJson = str_contains(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json');

function clean(mixed $v, int $max = 200): string
{
    return trim(mb_substr(preg_replace('/[\r\n\t]+/', ' ', strip_tags((string) $v)) ?? '', 0, $max));
}

/** Responde en JSON (fetch) o con una página sencilla (formulario sin JavaScript). */
function reply(int $code, array $data): never
{
    global $isJson;
    http_response_code($code);
    if ($isJson) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    $ok = !empty($data['ok']);
    $title = $ok ? '¡Solicitud enviada con éxito!' : 'No hemos podido enviar tu solicitud';
    $text = $ok
        ? 'Te escribiremos en breve para activar tu cuenta con 7 días gratis.'
        : 'Revisa los datos e inténtalo de nuevo, o escríbenos a contacto@bookmy.es.';
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . htmlspecialchars($title) . ' · Bookmy</title>'
        . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#030706;color:#eaf6f1;font:17px/1.6 system-ui,sans-serif;padding:24px}'
        . 'main{max-width:520px;text-align:center}h1{font-size:30px;line-height:1.15;margin:0 0 12px}a{color:#c7d761;font-weight:700}</style></head>'
        . '<body><main><h1>' . htmlspecialchars($title) . '</h1><p>' . htmlspecialchars($text) . '</p>'
        . '<p><a href="../crear-cuenta.html">Volver al formulario</a> · <a href="../crm.html">Ir al CRM</a></p></main></body></html>';
    exit;
}

header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

// Origen: la propia web y los dominios permitidos
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$self = ($https ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
$allowed = array_merge(ALLOWED_ORIGINS, [$self]);
if ($origin !== '' && in_array($origin, $allowed, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
    exit;
}
if ($method !== 'POST') reply(405, ['error' => 'method_not_allowed']);
if ($origin !== '' && !in_array($origin, $allowed, true)) reply(403, ['error' => 'origin_not_allowed']);

// Datos: JSON o formulario
$in = $isJson ? json_decode((string) file_get_contents('php://input'), true) : $_POST;
if (!is_array($in)) reply(400, ['error' => 'bad_request']);
if (clean($in['web'] ?? '') !== '') reply(200, ['ok' => true]); // campo trampa: los bots lo rellenan

// Límite de envíos por IP
$bucket = sys_get_temp_dir() . '/bookmy_alta_' . hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0') . date('Ymd'));
$now = time();
$hits = array_filter((array) json_decode((string) @file_get_contents($bucket), true), fn($t) => (int) $t > $now - RATE_WINDOW);
if (count($hits) >= RATE_LIMIT) reply(429, ['error' => 'rate_limited']);

// Validación
$planKey = strtolower(clean($in['plan'] ?? 'pro', 10));
if ($planKey === 'free') $planKey = 'basic';
if (!isset(PLANES[$planKey])) $planKey = 'pro';
$plan = PLANES[$planKey];
$nombre = clean($in['nombre'] ?? '', 80);
$email = filter_var(clean($in['email'] ?? '', 160), FILTER_VALIDATE_EMAIL) ?: '';
$telefono = clean($in['telefono'] ?? '', 30);
$pais = clean($in['pais'] ?? '', 60);
$tipo = clean($in['tipo'] ?? '', 40);
$negocio = clean($in['negocio'] ?? '', 100);
$consent = $in['consentimiento'] ?? false;
$consent = $consent === true || $consent === 'si' || $consent === 'on' || $consent === '1';

if (mb_strlen($nombre) < 2) reply(422, ['error' => 'nombre']);
if ($email === '') reply(422, ['error' => 'email']);
if (strlen(preg_replace('/\D/', '', $telefono) ?? '') < 7) reply(422, ['error' => 'telefono']);
if ($pais === '') reply(422, ['error' => 'pais']);
if (!in_array($tipo, TIPOS, true)) reply(422, ['error' => 'tipo']);
if (!$consent) reply(422, ['error' => 'consentimiento']);

$hits[] = $now;
@file_put_contents($bucket, json_encode(array_values($hits)), LOCK_EX);

// Email
$fecha = (new DateTimeImmutable('now', new DateTimeZone('Europe/Madrid')))->format('d/m/Y H:i');
$subject = "Nueva solicitud de alta · {$plan} · {$nombre}";
$body = "Nueva solicitud de alta desde bookmy.es\n"
    . str_repeat('-', 44) . "\n"
    . "Plan:             {$plan} (7 días gratis)\n"
    . "Nombre completo:  {$nombre}\n"
    . "Correo:           {$email}\n"
    . "Teléfono:         {$telefono}\n"
    . "País:             {$pais}\n"
    . "Tipo de empresa:  {$tipo}\n"
    . 'Negocio:          ' . ($negocio !== '' ? $negocio : '—') . "\n"
    . str_repeat('-', 44) . "\n"
    . "Fecha:            {$fecha} (hora de Madrid)\n"
    . 'Página:           ' . clean($in['pagina'] ?? 'crear-cuenta.html', 80) . "\n"
    . "Consentimiento:   sí, aceptó la política de privacidad\n\n"
    . "Responde a este correo para escribir directamente a {$nombre}.\n";

$headers = 'From: Bookmy <' . FROM . ">\r\n"
    . 'Cc: ' . CC . "\r\n"
    . "Reply-To: {$email}\r\n"
    . "MIME-Version: 1.0\r\n"
    . "Content-Type: text/plain; charset=UTF-8\r\n"
    . "Content-Transfer-Encoding: 8bit\r\n";

$ok = mail(TO, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);

reply($ok ? 200 : 500, $ok ? ['ok' => true] : ['ok' => false, 'error' => 'mail']);
