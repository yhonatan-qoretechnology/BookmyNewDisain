<?php
/**
 * Bookmy · Proxy del asistente IA (PHP 8.1+ con cURL)
 *
 * El chat de la web (js/assistant.js) envía aquí la conversación y este archivo
 * responde con Claude (API de Anthropic). La clave nunca llega al navegador.
 *
 * Configuración (una de las dos):
 *   1) Variable de entorno ANTHROPIC_API_KEY (recomendado; en cPanel: "Variables de entorno"
 *      o SetEnv en .htaccess fuera de public_html si tu hosting lo permite).
 *   2) Copia config.example.php como config.php y pon ahí la clave. No lo subas a GitHub.
 *
 * Después, en js/assistant.js pon:  endpoint: 'api/asistente.php'
 */
declare(strict_types=1);

const ALLOWED_ORIGINS = ['https://bookmy.es', 'https://www.bookmy.es'];
const MAX_MESSAGES = 14;   // últimos mensajes que se envían al modelo
const MAX_CHARS = 1200;    // por mensaje
const RATE_LIMIT = 30;     // mensajes por IP…
const RATE_WINDOW = 600;   // …cada 10 minutos

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function out(int $code, array $data): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && in_array($origin, ALLOWED_ORIGINS, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
    exit;
}
if ($method !== 'POST') out(405, ['error' => 'method_not_allowed']);
if ($origin !== '' && !in_array($origin, ALLOWED_ORIGINS, true)) out(403, ['error' => 'origin_not_allowed']);

$config = is_file(__DIR__ . '/config.php') ? (array) require __DIR__ . '/config.php' : [];
$apiKey = getenv('ANTHROPIC_API_KEY') ?: (string) ($config['anthropic_api_key'] ?? '');
$model = getenv('BOOKMY_AI_MODEL') ?: (string) ($config['model'] ?? 'claude-haiku-5-5');
if ($apiKey === '') out(500, ['error' => 'not_configured']);

/* Límite por IP. Se guarda un hash diario de la IP, nunca la IP en claro. */
$bucket = sys_get_temp_dir() . '/bookmy_ai_' . hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0') . date('Ymd'));
$now = time();
$hits = array_filter((array) json_decode((string) @file_get_contents($bucket), true), fn($t) => (int) $t > $now - RATE_WINDOW);
if (count($hits) >= RATE_LIMIT) out(429, ['error' => 'rate_limited']);
$hits[] = $now;
@file_put_contents($bucket, json_encode(array_values($hits)), LOCK_EX);

/* Entrada */
$in = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($in) || !is_array($in['messages'] ?? null)) out(400, ['error' => 'bad_request']);

/* Conversación limpia: roles alternos y empieza por el usuario */
$msgs = [];
foreach (array_slice($in['messages'], -MAX_MESSAGES) as $m) {
    if (!is_array($m)) continue;
    $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
    $text = trim(mb_substr(strip_tags((string) ($m['content'] ?? '')), 0, MAX_CHARS));
    if ($text === '') continue;
    if ($msgs && $msgs[count($msgs) - 1]['role'] === $role) {
        $msgs[count($msgs) - 1]['content'] .= "\n\n" . $text;
        continue;
    }
    $msgs[] = ['role' => $role, 'content' => $text];
}
while ($msgs && $msgs[0]['role'] !== 'user') array_shift($msgs);
if (!$msgs || $msgs[count($msgs) - 1]['role'] !== 'user') out(400, ['error' => 'no_user_message']);

$page = preg_replace('/[^a-z\-]/', '', (string) ($in['page'] ?? ''));
$allowed = ['sector', 'sectorLabel', 'team', 'sedes', 'pain', 'name', 'citas', 'ticket', 'rate'];
$profile = array_intersect_key((array) ($in['profile'] ?? []), array_flip($allowed));

$system = (string) @file_get_contents(__DIR__ . '/prompt-vendedor.md');
$system .= "\n\n## Contexto de esta conversación\n"
    . '- Página que está viendo: ' . ($page ?: 'desconocida') . "\n"
    . '- Datos que ha dado el visitante: ' . json_encode($profile, JSON_UNESCAPED_UNICODE);

/* Llamada a la API de mensajes de Anthropic */
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 25,
    CURLOPT_HTTPHEADER => [
        'content-type: application/json',
        'x-api-key: ' . $apiKey,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_POSTFIELDS => json_encode([
        'model' => $model,
        'max_tokens' => 700,
        'system' => $system,
        'messages' => $msgs,
    ], JSON_UNESCAPED_UNICODE),
]);
$res = curl_exec($ch);
$status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
if ($res === false || $status >= 400) out(502, ['error' => 'upstream_error']);

$data = json_decode((string) $res, true);
$reply = '';
foreach ((array) ($data['content'] ?? []) as $block) {
    if (is_array($block) && ($block['type'] ?? '') === 'text') $reply .= (string) $block['text'];
}
$reply = trim($reply);
if ($reply === '') out(502, ['error' => 'empty_reply']);

out(200, ['reply' => $reply]);
