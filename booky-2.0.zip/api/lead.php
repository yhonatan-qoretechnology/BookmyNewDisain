<?php
/**
 * Bookmy · Recibe los contactos del asistente y las altas de la newsletter
 * y los envía por email. PHP 8.1+ con mail() habilitado (lo normal en cPanel).
 *
 * Para activarlo:
 *   - js/assistant.js →  leadEndpoint: 'api/lead.php'
 *   - Pie de página   →  <form data-newsletter data-endpoint="api/lead.php">
 */
declare(strict_types=1);

const ALLOWED_ORIGINS = ['https://bookmy.es', 'https://www.bookmy.es'];
const TO = 'contacto@bookmy.es';
const FROM = 'no-reply@bookmy.es';   // usa un buzón de tu dominio para que no acabe en spam
const RATE_LIMIT = 6;                 // envíos por IP…
const RATE_WINDOW = 3600;             // …cada hora

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function out(int $code, array $data): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function clean(mixed $v, int $max = 200): string
{
    return trim(mb_substr(preg_replace('/[\r\n\t]+/', ' ', strip_tags((string) $v)), 0, $max));
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && in_array($origin, ALLOWED_ORIGINS, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
    exit;
}
if ($method !== 'POST') out(405, ['error' => 'method_not_allowed']);
if ($origin !== '' && !in_array($origin, ALLOWED_ORIGINS, true)) out(403, ['error' => 'origin_not_allowed']);

$bucket = sys_get_temp_dir() . '/bookmy_lead_' . hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0') . date('Ymd'));
$now = time();
$hits = array_filter((array) json_decode((string) @file_get_contents($bucket), true), fn($t) => (int) $t > $now - RATE_WINDOW);
if (count($hits) >= RATE_LIMIT) out(429, ['error' => 'rate_limited']);
$hits[] = $now;
@file_put_contents($bucket, json_encode(array_values($hits)), LOCK_EX);

$in = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($in)) out(400, ['error' => 'bad_request']);
if (clean($in['web'] ?? '') !== '') out(200, ['ok' => true]); // campo trampa para bots

$email = filter_var(clean($in['email'] ?? '', 160), FILTER_VALIDATE_EMAIL) ?: '';
$origen = clean($in['origen'] ?? 'asistente', 30);

if ($origen === 'newsletter') {
    if ($email === '') out(422, ['error' => 'email']);
    $subject = 'Alta en la newsletter';
    $body = "Nueva alta en la newsletter desde bookmy.es\n\nEmail: {$email}\nFecha: " . date('c') . "\n";
} else {
    $nombre = clean($in['nombre'] ?? '', 80);
    $telefono = clean($in['telefono'] ?? '', 30);
    if (mb_strlen($nombre) < 2) out(422, ['error' => 'nombre']);
    if ($email === '' && strlen(preg_replace('/\D/', '', $telefono)) < 7) out(422, ['error' => 'contacto']);
    if (($in['consentimiento'] ?? false) !== true) out(422, ['error' => 'consentimiento']);
    $perfil = json_encode((array) ($in['perfil'] ?? []), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $subject = 'Nuevo contacto: ' . $nombre;
    $body = "Nuevo contacto desde el asistente de bookmy.es\n\n"
        . "Nombre: {$nombre}\n"
        . 'Email: ' . ($email ?: '—') . "\n"
        . 'Teléfono: ' . ($telefono ?: '—') . "\n"
        . 'Tipo de empresa: ' . (clean($in['tipo'] ?? '', 40) ?: '—') . "\n"
        . 'Página: ' . clean($in['pagina'] ?? '', 40) . "\n\n"
        . 'Resumen: ' . clean($in['resumen'] ?? '', 600) . "\n\n"
        . "Datos de la conversación:\n{$perfil}\n\n"
        . 'Consentimiento: sí, ' . date('c') . "\n";
}

$headers = 'From: Bookmy <' . FROM . ">\r\n"
    . "Content-Type: text/plain; charset=UTF-8\r\n"
    . ($email !== '' ? "Reply-To: {$email}\r\n" : '');
$ok = mail(TO, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);

out($ok ? 200 : 500, ['ok' => $ok]);
