<?php
/**
 * Copia este archivo como config.php (en la misma carpeta) solo si no puedes
 * usar variables de entorno. No lo subas nunca a un repositorio público.
 */
return [
    // Asistente con IA (api/asistente.php)
    'anthropic_api_key' => 'pon-aqui-tu-clave',
    'model' => 'claude-haiku-5-5', // rápido y económico para chat

    // Formulario de alta (api/registro.php)
    'registro_to' => 'appbookmy20025@gmail.com',  // a quién llegan las solicitudes
    'registro_cc' => 'info@qoretechnology.com',   // copia
    'mail_from' => 'no-reply@bookmy.es',          // remitente: un buzón de tu dominio
];
